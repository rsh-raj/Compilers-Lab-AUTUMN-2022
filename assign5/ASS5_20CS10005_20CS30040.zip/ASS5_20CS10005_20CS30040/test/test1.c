  int a, b, c;
    int d = 99, e, f;
    float g, h, i;
int main()
{

  
    char j, k, l;
    int m[10], n[10], o[10];
    int p[10][10], q[10][10], r[10][10];
    a = -1, b = 2, c = 3;
    j = 'a', k = 'b', l = 'c';
    g = 1.1, h = 2.2, i = 3.3;
    a = b + c;
    a = b - c;
    a = b * c;
    a = b / c;
    a = b % c;

       a = b << c;
    a = b >> c;
    return 0;
}
