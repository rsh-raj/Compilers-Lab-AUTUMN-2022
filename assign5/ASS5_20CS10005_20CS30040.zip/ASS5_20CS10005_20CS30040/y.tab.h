/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    AUTO = 258,
    ENUM = 259,
    RESTRICT = 260,
    UNSIGNED = 261,
    BREAK = 262,
    EXTERN = 263,
    RETURN = 264,
    VOIDTYPE = 265,
    CASE = 266,
    FLOATTYPE = 267,
    SHORT = 268,
    VOLATILE = 269,
    CHARTYPE = 270,
    FOR = 271,
    SIGNED = 272,
    WHILE = 273,
    CONST = 274,
    GOTO = 275,
    SIZEOF = 276,
    BOOL = 277,
    CONTINUE = 278,
    IF = 279,
    STATIC = 280,
    COMPLEX = 281,
    DEFAULT = 282,
    INLINE = 283,
    STRUCT = 284,
    IMAGINARY = 285,
    DO = 286,
    INTTYPE = 287,
    SWITCH = 288,
    DOUBLE = 289,
    LONG = 290,
    TYPEDEF = 291,
    ELSE = 292,
    REGISTER = 293,
    UNION = 294,
    IDENTIFIER = 295,
    INTEGER_CONSTANT = 296,
    FLOATING_CONSTANT = 297,
    CHARACTER_CONSTANT = 298,
    STRING_LITERAL = 299,
    ARROW = 300,
    INCREMENT = 301,
    DECREMENT = 302,
    LEFT_SHIFT = 303,
    RIGHT_SHIFT = 304,
    LESS_THAN_EQUAL = 305,
    GREATER_THAN_EQUAL = 306,
    EQUAL = 307,
    NOT_EQUAL = 308,
    LOGICAL_AND = 309,
    LOGICAL_OR = 310,
    THREE_DOT = 311,
    MULTIPLY_ASSIGN = 312,
    DIVIDE_ASSIGN = 313,
    MOD_ASSIGN = 314,
    ADD_ASSIGN = 315,
    SUB_ASSIGN = 316,
    SHIFT_LEFT_ASSIGN = 317,
    SHIFT_RIGHT_ASSIGN = 318,
    AND_ASSIGN = 319,
    XOR_ASSIGN = 320,
    OR_ASSIGN = 321,
    UNEXPECTED = 322,
    RIGHT_PARENTHESES = 323,
    THEN = 324
  };
#endif
/* Tokens.  */
#define AUTO 258
#define ENUM 259
#define RESTRICT 260
#define UNSIGNED 261
#define BREAK 262
#define EXTERN 263
#define RETURN 264
#define VOIDTYPE 265
#define CASE 266
#define FLOATTYPE 267
#define SHORT 268
#define VOLATILE 269
#define CHARTYPE 270
#define FOR 271
#define SIGNED 272
#define WHILE 273
#define CONST 274
#define GOTO 275
#define SIZEOF 276
#define BOOL 277
#define CONTINUE 278
#define IF 279
#define STATIC 280
#define COMPLEX 281
#define DEFAULT 282
#define INLINE 283
#define STRUCT 284
#define IMAGINARY 285
#define DO 286
#define INTTYPE 287
#define SWITCH 288
#define DOUBLE 289
#define LONG 290
#define TYPEDEF 291
#define ELSE 292
#define REGISTER 293
#define UNION 294
#define IDENTIFIER 295
#define INTEGER_CONSTANT 296
#define FLOATING_CONSTANT 297
#define CHARACTER_CONSTANT 298
#define STRING_LITERAL 299
#define ARROW 300
#define INCREMENT 301
#define DECREMENT 302
#define LEFT_SHIFT 303
#define RIGHT_SHIFT 304
#define LESS_THAN_EQUAL 305
#define GREATER_THAN_EQUAL 306
#define EQUAL 307
#define NOT_EQUAL 308
#define LOGICAL_AND 309
#define LOGICAL_OR 310
#define THREE_DOT 311
#define MULTIPLY_ASSIGN 312
#define DIVIDE_ASSIGN 313
#define MOD_ASSIGN 314
#define ADD_ASSIGN 315
#define SUB_ASSIGN 316
#define SHIFT_LEFT_ASSIGN 317
#define SHIFT_RIGHT_ASSIGN 318
#define AND_ASSIGN 319
#define XOR_ASSIGN 320
#define OR_ASSIGN 321
#define UNEXPECTED 322
#define RIGHT_PARENTHESES 323
#define THEN 324

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 11 "bison2.y"

    int intVal;
    float floatVal;
    char *charName;
    char *stringName;
    char *identifierName;
    char *unaryOperator;
    int instructionNumber;
    int parameterCount;
    Expression *expression;
    Statement *statement;
    Array *array;
    SymbolType *symbolType;
    Symbol *symbol;

#line 211 "y.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
