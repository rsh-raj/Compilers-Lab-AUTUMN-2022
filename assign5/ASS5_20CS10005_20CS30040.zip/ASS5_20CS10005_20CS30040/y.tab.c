/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.5.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "bison2.y"

    #include "translator.h"
    extern int yylex();
    extern int yylineno;
    void yyerror(string s);
    void yyinfo(string s);
    void yyreduce(string s);
    extern int yylineno;

#line 80 "y.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    AUTO = 258,
    ENUM = 259,
    RESTRICT = 260,
    UNSIGNED = 261,
    BREAK = 262,
    EXTERN = 263,
    RETURN = 264,
    VOIDTYPE = 265,
    CASE = 266,
    FLOATTYPE = 267,
    SHORT = 268,
    VOLATILE = 269,
    CHARTYPE = 270,
    FOR = 271,
    SIGNED = 272,
    WHILE = 273,
    CONST = 274,
    GOTO = 275,
    SIZEOF = 276,
    BOOL = 277,
    CONTINUE = 278,
    IF = 279,
    STATIC = 280,
    COMPLEX = 281,
    DEFAULT = 282,
    INLINE = 283,
    STRUCT = 284,
    IMAGINARY = 285,
    DO = 286,
    INTTYPE = 287,
    SWITCH = 288,
    DOUBLE = 289,
    LONG = 290,
    TYPEDEF = 291,
    ELSE = 292,
    REGISTER = 293,
    UNION = 294,
    IDENTIFIER = 295,
    INTEGER_CONSTANT = 296,
    FLOATING_CONSTANT = 297,
    CHARACTER_CONSTANT = 298,
    STRING_LITERAL = 299,
    ARROW = 300,
    INCREMENT = 301,
    DECREMENT = 302,
    LEFT_SHIFT = 303,
    RIGHT_SHIFT = 304,
    LESS_THAN_EQUAL = 305,
    GREATER_THAN_EQUAL = 306,
    EQUAL = 307,
    NOT_EQUAL = 308,
    LOGICAL_AND = 309,
    LOGICAL_OR = 310,
    THREE_DOT = 311,
    MULTIPLY_ASSIGN = 312,
    DIVIDE_ASSIGN = 313,
    MOD_ASSIGN = 314,
    ADD_ASSIGN = 315,
    SUB_ASSIGN = 316,
    SHIFT_LEFT_ASSIGN = 317,
    SHIFT_RIGHT_ASSIGN = 318,
    AND_ASSIGN = 319,
    XOR_ASSIGN = 320,
    OR_ASSIGN = 321,
    UNEXPECTED = 322,
    RIGHT_PARENTHESES = 323,
    THEN = 324
  };
#endif
/* Tokens.  */
#define AUTO 258
#define ENUM 259
#define RESTRICT 260
#define UNSIGNED 261
#define BREAK 262
#define EXTERN 263
#define RETURN 264
#define VOIDTYPE 265
#define CASE 266
#define FLOATTYPE 267
#define SHORT 268
#define VOLATILE 269
#define CHARTYPE 270
#define FOR 271
#define SIGNED 272
#define WHILE 273
#define CONST 274
#define GOTO 275
#define SIZEOF 276
#define BOOL 277
#define CONTINUE 278
#define IF 279
#define STATIC 280
#define COMPLEX 281
#define DEFAULT 282
#define INLINE 283
#define STRUCT 284
#define IMAGINARY 285
#define DO 286
#define INTTYPE 287
#define SWITCH 288
#define DOUBLE 289
#define LONG 290
#define TYPEDEF 291
#define ELSE 292
#define REGISTER 293
#define UNION 294
#define IDENTIFIER 295
#define INTEGER_CONSTANT 296
#define FLOATING_CONSTANT 297
#define CHARACTER_CONSTANT 298
#define STRING_LITERAL 299
#define ARROW 300
#define INCREMENT 301
#define DECREMENT 302
#define LEFT_SHIFT 303
#define RIGHT_SHIFT 304
#define LESS_THAN_EQUAL 305
#define GREATER_THAN_EQUAL 306
#define EQUAL 307
#define NOT_EQUAL 308
#define LOGICAL_AND 309
#define LOGICAL_OR 310
#define THREE_DOT 311
#define MULTIPLY_ASSIGN 312
#define DIVIDE_ASSIGN 313
#define MOD_ASSIGN 314
#define ADD_ASSIGN 315
#define SUB_ASSIGN 316
#define SHIFT_LEFT_ASSIGN 317
#define SHIFT_RIGHT_ASSIGN 318
#define AND_ASSIGN 319
#define XOR_ASSIGN 320
#define OR_ASSIGN 321
#define UNEXPECTED 322
#define RIGHT_PARENTHESES 323
#define THEN 324

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 11 "bison2.y"

    int intVal;
    float floatVal;
    char *charName;
    char *stringName;
    char *identifierName;
    char *unaryOperator;
    int instructionNumber;
    int parameterCount;
    Expression *expression;
    Statement *statement;
    Array *array;
    SymbolType *symbolType;
    Symbol *symbol;

#line 286 "y.tab.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */



#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))

/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && ! defined __ICC && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                            \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  48
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1150

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  94
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  75
/* YYNRULES -- Number of rules.  */
#define YYNRULES  213
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  368

#define YYUNDEFTOK  2
#define YYMAXUTOK   324


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    83,     2,     2,     2,    85,    78,     2,
      70,    71,    79,    80,    77,    81,    74,    84,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    91,    93,
      86,    92,    87,    90,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    72,     2,    73,    88,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    75,    89,    76,    82,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   170,   170,   176,   182,   189,   196,   203,   211,   219,
     240,   249,   255,   259,   269,   279,   283,   290,   296,   306,
     313,   323,   328,   335,   342,   369,   373,   384,   389,   394,
     399,   404,   409,   417,   422,   441,   457,   480,   503,   529,
     534,   545,   559,   564,   575,   596,   601,   615,   629,   643,
     660,   665,   681,   709,   714,   727,   732,   745,   750,   770,
     777,   814,   819,   833,   838,   852,   857,   877,   882,   903,
     907,   911,   915,   919,   923,   927,   931,   935,   939,   943,
     950,   955,   962,   971,   978,   983,   989,   993,   997,  1001,
    1008,  1013,  1019,  1023,  1030,  1035,  1047,  1051,  1055,  1059,
    1066,  1071,  1076,  1080,  1085,  1089,  1094,  1098,  1102,  1106,
    1110,  1114,  1118,  1125,  1129,  1136,  1141,  1147,  1151,  1155,
    1162,  1167,  1173,  1177,  1184,  1188,  1195,  1199,  1203,  1210,
    1217,  1226,  1233,  1249,  1255,  1260,  1264,  1268,  1286,  1305,
    1309,  1313,  1317,  1321,  1325,  1340,  1344,  1362,  1367,  1400,
    1406,  1415,  1419,  1426,  1430,  1437,  1441,  1448,  1452,  1459,
    1463,  1470,  1477,  1482,  1486,  1493,  1497,  1504,  1509,  1515,
    1522,  1526,  1533,  1537,  1546,  1550,  1555,  1561,  1566,  1571,
    1579,  1583,  1587,  1599,  1610,  1619,  1625,  1632,  1637,  1647,
    1652,  1660,  1668,  1674,  1694,  1702,  1711,  1737,  1747,  1756,
    1767,  1774,  1778,  1782,  1786,  1801,  1805,  1812,  1816,  1824,
    1834,  1839,  1845,  1849
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "AUTO", "ENUM", "RESTRICT", "UNSIGNED",
  "BREAK", "EXTERN", "RETURN", "VOIDTYPE", "CASE", "FLOATTYPE", "SHORT",
  "VOLATILE", "CHARTYPE", "FOR", "SIGNED", "WHILE", "CONST", "GOTO",
  "SIZEOF", "BOOL", "CONTINUE", "IF", "STATIC", "COMPLEX", "DEFAULT",
  "INLINE", "STRUCT", "IMAGINARY", "DO", "INTTYPE", "SWITCH", "DOUBLE",
  "LONG", "TYPEDEF", "ELSE", "REGISTER", "UNION", "IDENTIFIER",
  "INTEGER_CONSTANT", "FLOATING_CONSTANT", "CHARACTER_CONSTANT",
  "STRING_LITERAL", "ARROW", "INCREMENT", "DECREMENT", "LEFT_SHIFT",
  "RIGHT_SHIFT", "LESS_THAN_EQUAL", "GREATER_THAN_EQUAL", "EQUAL",
  "NOT_EQUAL", "LOGICAL_AND", "LOGICAL_OR", "THREE_DOT", "MULTIPLY_ASSIGN",
  "DIVIDE_ASSIGN", "MOD_ASSIGN", "ADD_ASSIGN", "SUB_ASSIGN",
  "SHIFT_LEFT_ASSIGN", "SHIFT_RIGHT_ASSIGN", "AND_ASSIGN", "XOR_ASSIGN",
  "OR_ASSIGN", "UNEXPECTED", "RIGHT_PARENTHESES", "THEN", "'('", "')'",
  "'['", "']'", "'.'", "'{'", "'}'", "','", "'&'", "'*'", "'+'", "'-'",
  "'~'", "'!'", "'/'", "'%'", "'<'", "'>'", "'^'", "'|'", "'?'", "':'",
  "'='", "';'", "$accept", "primary_expression", "postfix_expression",
  "argument_expression_list_opt", "argument_expression_list",
  "unary_expression", "unary_operator", "cast_expression",
  "multiplicative_expression", "additive_expression", "shift_expression",
  "relational_expression", "equality_expression", "AND_expression",
  "exclusive_OR_expression", "inclusive_OR_expression", "M", "N",
  "logical_AND_expression", "logical_OR_expression",
  "conditional_expression", "assignment_expression", "assignment_operator",
  "expression", "constant_expression", "declaration",
  "init_declarator_list_opt", "declaration_specifiers",
  "declaration_specifiers_opt", "init_declarator_list", "init_declarator",
  "storage_class_specifier", "type_specifier", "specifier_qualifier_list",
  "specifier_qualifier_list_opt", "enum_specifier", "identifier_opt",
  "enumerator_list", "enumerator", "type_qualifier", "function_specifier",
  "declarator", "change_scope", "direct_declarator",
  "type_qualifier_list_opt", "pointer", "type_qualifier_list",
  "parameter_type_list", "parameter_list", "parameter_declaration",
  "identifier_list", "type_name", "initialiser", "initialiser_list",
  "designation_opt", "designation", "designator_list", "designator",
  "statement", "labeled_statement", "change_block", "compound_statement",
  "block_item_list_opt", "block_item_list", "block_item",
  "expression_statement", "expression_opt", "selection_statement",
  "iteration_statement", "jump_statement", "translation_unit",
  "external_declaration", "function_definition", "declaration_list_opt",
  "declaration_list", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_int16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
      40,    41,    91,    93,    46,   123,   125,    44,    38,    42,
      43,    45,   126,    33,    47,    37,    60,    62,    94,   124,
      63,    58,    61,    59
};
# endif

#define YYPACT_NINF (-297)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-212)

#define yytable_value_is_error(Yyn) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    1080,  -297,    -6,  -297,  -297,  -297,  -297,  -297,  -297,  -297,
    -297,  -297,  -297,  -297,  -297,  -297,  -297,  -297,  -297,  -297,
    -297,  -297,  -297,   -24,  1080,  1080,  -297,  1080,  1080,  1044,
    -297,  -297,   -37,   -21,  -297,   -24,    61,    21,    48,  -297,
     370,   -33,   -23,  -297,  -297,  -297,  -297,  -297,  -297,  -297,
      30,    70,  -297,    65,    61,  -297,   -24,   801,  -297,   -24,
    -297,  1080,    97,   170,   -33,    68,   -53,  -297,  -297,  -297,
    -297,  -297,    81,   864,  -297,  -297,  -297,  -297,  -297,   880,
     880,   567,    -3,  -297,  -297,  -297,  -297,  -297,  -297,  -297,
     100,   197,   927,  -297,    23,   -32,   132,   -29,   144,    72,
      89,    69,    99,   -30,  -297,  -297,  -297,   108,  -297,  -297,
     802,   -35,   655,  -297,   112,   114,   611,   927,  -297,   -25,
     567,  -297,   567,  -297,  -297,  -297,     2,  1115,  -297,  1115,
     119,   927,   152,   125,   801,  -297,   -39,  -297,   154,  -297,
    -297,   927,   927,   159,  -297,  -297,  -297,  -297,  -297,  -297,
    -297,  -297,  -297,  -297,  -297,   927,  -297,  -297,   927,   927,
     927,   927,   927,   927,   927,   927,   927,   927,   927,   927,
     927,   927,   927,   927,  -297,  -297,   116,   288,  -297,   -24,
     138,   145,  -297,  -297,   188,   156,   655,  -297,  -297,   927,
    -297,   157,   158,  -297,  -297,  -297,  -297,   162,   166,  -297,
     927,  -297,  -297,  -297,   817,   165,  -297,  -297,    59,  -297,
    -297,  -297,  -297,   168,   167,  -297,    66,  -297,  -297,  -297,
    -297,  -297,    23,    23,   -32,   -32,   132,   132,   132,   132,
     -29,   -29,   144,    72,    89,   927,   927,  -297,   149,   927,
     927,   175,  -297,   206,   171,   177,   174,  -297,   196,   176,
    -297,   191,  -297,  -297,  -297,  -297,   195,   198,  -297,  -297,
     183,  -297,  -297,  -297,  -297,  -297,  1008,  -297,  -297,   204,
     205,  -297,  -297,   207,   207,  -297,    -3,  -297,  -297,  -297,
     801,  -297,   927,  -297,    69,    99,   927,  -297,   186,   189,
     487,   211,   190,  -297,   927,   699,   699,   927,   699,  -297,
    -297,   406,  -297,  -297,  -297,  -297,  -297,   127,  -297,  -297,
     191,  -297,   699,   927,   192,   927,  -297,    33,  -297,  -297,
      44,  -297,   288,  -297,  -297,    64,   193,  -297,   194,  -297,
      46,  -297,   268,   699,   212,  -297,  -297,   927,   927,  -297,
     699,   247,  -297,  -297,   927,   253,   232,   699,  -297,   927,
    -297,   699,  -297,  -297,   290,    47,  -297,   927,  -297,   240,
    -297,   699,  -297,   265,  -297,  -297,   699,  -297
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,    98,   121,   127,   108,    96,   100,   105,   102,   128,
     101,   107,   126,   109,    97,   110,   129,   111,   103,   106,
     104,    99,   208,    85,    91,    91,   112,    91,    91,     0,
     205,   207,   119,     0,   133,     0,   148,     0,    84,    92,
      94,   131,     0,    90,    86,    87,    88,    89,     1,   206,
       0,     0,   151,   149,   147,    83,     0,     0,   212,    85,
     132,   210,   132,     0,   130,   124,     0,   122,   134,   150,
     152,    93,    94,     0,     2,     3,     4,     5,     6,     0,
       0,     0,   168,    27,    28,    29,    30,    31,    32,     8,
      21,    33,     0,    35,    39,    42,    45,    50,    53,    55,
      57,    61,    63,    65,    67,   162,    95,     0,   213,   159,
       0,     0,     0,   138,    28,     0,     0,     0,   117,     0,
       0,    25,     0,    22,    23,    80,     0,   116,   161,   116,
       0,     0,     0,     0,     0,   167,     0,   170,     0,    13,
      14,    18,     0,     0,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    69,     0,    33,    24,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    59,    59,     0,   186,   146,   158,
       0,   153,   155,   145,     0,     0,     0,   143,   137,     0,
     136,    28,     0,    82,   125,   118,   123,     0,     0,     7,
       0,   115,   113,   114,     0,     0,   173,   163,   168,   165,
     169,   171,    12,     0,    17,    19,     0,    11,    68,    36,
      37,    38,    40,    41,    43,    44,    48,    49,    46,    47,
      51,    52,    54,    56,    58,     0,     0,    59,     0,   193,
       0,     0,    59,     0,     0,     0,     0,    59,     0,     2,
     183,   192,   189,   190,   174,   175,     0,    59,   187,   176,
       0,   177,   178,   179,   157,   144,     0,   160,   140,     0,
       0,   142,   135,    26,     0,    81,   168,    34,   172,   164,
       0,    10,     0,     9,    62,    64,     0,   203,     0,     0,
     193,     0,     0,   202,     0,   193,   193,     0,   193,   132,
     209,   193,   191,   154,   156,   139,   141,     0,   166,    20,
      60,   204,   193,   193,     0,     0,   201,     0,   182,    59,
       0,   180,   186,   188,    15,   168,     0,   181,     0,    59,
       0,    59,     0,   193,     0,    16,    59,   193,   193,    59,
     193,     0,   196,   184,     0,     0,     0,   193,    60,     0,
      66,   193,    59,   197,   194,     0,   200,   193,    59,     0,
      60,   193,   198,     0,   195,    59,   193,   199
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -297,  -297,  -297,  -297,  -297,   -72,  -297,   -82,    58,    60,
     -84,    56,   169,   172,   164,   103,  -131,  -296,   105,  -297,
    -112,    -7,  -297,   -79,  -120,     0,  -297,     3,   124,  -297,
     283,  -297,   -55,    27,   213,  -297,  -297,  -297,   224,    49,
    -297,   -17,   -58,   303,  -297,   293,   -50,  -297,  -297,    82,
    -297,    37,  -125,    71,  -196,  -297,  -297,   214,   452,  -297,
    -297,  -297,    29,  -297,    51,  -297,  -171,  -297,  -297,  -297,
    -297,   320,  -297,  -297,  -297
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    89,    90,   213,   214,    91,    92,    93,    94,    95,
      96,    97,    98,    99,   100,   101,   235,   176,   102,   103,
     104,   125,   155,   251,   194,   252,    37,    59,    44,    38,
      39,    24,    25,   128,   202,    26,    33,    66,    67,    27,
      28,    72,   107,    41,    53,    42,    54,   180,   181,   182,
     111,   130,   106,   133,   134,   135,   136,   137,   253,   254,
     299,   255,   256,   257,   258,   259,   260,   261,   262,   263,
      29,    30,    31,    60,    61
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      22,   121,   126,    23,   110,   193,    40,   123,   124,   209,
     157,   205,   280,   116,   326,    65,    34,    34,    51,   193,
     156,   165,   166,   118,   119,   175,   127,    43,    43,    22,
      43,    43,    23,   131,    32,   132,   183,    62,  -120,    63,
      58,   126,   184,   126,   236,   156,    35,    35,   161,   162,
     105,   195,   354,   210,    50,    36,   115,   167,   168,   156,
     -60,   108,   186,   216,   363,   127,     3,   127,   288,   131,
      65,   132,   127,   199,   127,     9,   219,   220,   221,   200,
      12,   226,   227,   228,   229,    52,   156,   156,   156,   156,
     156,   156,   156,   156,   156,   156,   156,   156,   156,   156,
     156,   156,   158,    70,   331,   185,   286,   159,   160,   192,
     200,   291,    52,   179,    55,   333,   296,   339,   359,   314,
     289,   200,   277,   200,   200,    56,   301,   105,   193,   280,
     129,   131,   156,   132,   215,   279,   131,   109,   132,   283,
     335,    68,   328,   200,    36,   138,   139,   140,   218,    45,
     171,    46,    47,   174,   201,   308,   201,   197,   173,   198,
     117,    52,   264,   156,   156,    70,   345,   346,   156,   129,
     141,   129,   142,    57,   143,     3,   129,   172,   129,   269,
     163,   164,   270,   177,     9,   187,   360,   188,   332,    12,
     204,    73,   206,   275,   212,   112,   169,   170,   338,   217,
     340,   207,   208,   324,   325,   344,   237,   310,   347,   265,
      74,    75,    76,    77,    78,   317,    79,    80,   320,   222,
     223,   357,   266,   224,   225,   230,   231,   361,   267,   268,
     271,   272,   350,   273,   366,    70,   330,   274,   278,   281,
      81,   322,   287,   113,   282,   290,   292,   294,    83,   114,
      85,    86,    87,    88,   144,   145,   146,   147,   148,   149,
     150,   151,   152,   153,   293,   295,   297,   298,   200,   179,
     355,   300,   156,   105,  -185,   309,   302,   305,   306,   311,
     312,   315,   276,   316,   336,   329,   341,   337,   343,   154,
     313,     1,     2,     3,     4,   238,     5,   239,     6,   240,
       7,     8,     9,    10,   241,    11,   242,    12,   243,    73,
      13,   244,   245,    14,    15,   246,    16,   349,    17,   247,
      18,   248,    19,    20,   351,   352,    21,   358,   249,    75,
      76,    77,    78,   362,    79,    80,   365,   234,   284,    71,
     232,   285,   203,   196,   233,    64,    69,   307,   304,    49,
     211,   334,   323,     0,     0,     0,     0,     0,    81,     0,
       0,     0,     0,   250,     0,     0,    83,    84,    85,    86,
      87,    88,     0,     1,     2,     3,     4,     0,     5,     0,
       6,  -193,     7,     8,     9,    10,     0,    11,     0,    12,
       0,     0,    13,     0,     0,    14,    15,     0,    16,     0,
      17,     0,    18,     0,    19,    20,     0,     0,    21,     1,
       2,     3,     4,   238,     5,   239,     6,   240,     7,     8,
       9,    10,   241,    11,   242,    12,   243,    73,    13,   244,
     245,    14,    15,   246,    16,     0,    17,   247,    18,   248,
      19,    20,     0,     0,    21,  -211,   249,    75,    76,    77,
      78,     0,    79,    80,     0,     0,     0,     0,     0,     0,
       0,     0,    57,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    81,     0,     0,     0,
       0,   250,     0,     0,    83,    84,    85,    86,    87,    88,
       1,     2,     3,     4,     0,     5,     0,     6,     0,     7,
       8,     9,    10,     0,    11,     0,    12,     0,    73,    13,
       0,     0,    14,    15,     0,    16,     0,    17,     0,    18,
       0,    19,    20,     0,     0,    21,     0,    74,    75,    76,
      77,    78,     0,    79,    80,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    81,     0,     0,
       0,     0,     0,     0,     0,    83,    84,    85,    86,    87,
      88,     2,     3,     4,     0,     0,     0,     6,     0,     7,
       8,     9,    10,     0,    11,     0,    12,     0,    73,    13,
       0,     0,     0,    15,     0,     0,     0,    17,     0,    18,
       0,    19,    20,     0,     0,     0,     0,    74,    75,    76,
      77,    78,     0,    79,    80,     0,     3,     0,     0,     0,
       0,     0,     0,     0,     0,     9,     0,     0,     0,     0,
      12,     0,    73,     0,     0,     0,   189,    81,     0,     0,
       0,     0,     0,     0,     0,    83,    84,    85,    86,    87,
      88,    74,    75,    76,    77,    78,     0,    79,    80,     0,
       3,     0,     0,     0,     0,     0,     0,     0,     0,     9,
       0,     0,     0,     0,    12,     0,    73,     0,     0,     0,
       0,    81,     0,     0,   190,     0,     0,     0,     0,    83,
     191,    85,    86,    87,    88,    74,    75,    76,    77,    78,
       0,    79,    80,     0,     0,     0,   238,     0,   239,     0,
     240,     0,     0,     0,     0,   241,     0,   242,     0,   243,
      73,     0,   244,   245,     0,    81,   246,     0,     0,     0,
     247,     0,   248,    83,    84,    85,    86,    87,    88,   249,
      75,    76,    77,    78,     0,    79,    80,   318,   319,     0,
     321,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   327,     0,     0,     0,     0,    81,
       0,     0,     0,     0,   250,     0,     0,    83,    84,    85,
      86,    87,    88,     0,     0,   342,     0,     0,     0,     0,
       0,     0,   348,     0,     0,     0,     0,     0,     0,   353,
       0,     0,     0,   356,     0,     1,     2,     3,     4,     0,
       5,     0,     6,   364,     7,     8,     9,    10,   367,    11,
       0,    12,    73,     0,    13,     0,     0,    14,    15,     0,
      16,     0,    17,     0,    18,     0,    19,    20,    73,     0,
      21,    74,    75,    76,    77,    78,     0,    79,    80,     0,
       0,     0,     0,     0,     0,     0,     0,    74,    75,    76,
      77,    78,     0,    79,    80,     0,     0,     0,     0,     0,
       0,    81,     0,   178,     0,     0,    82,     0,     0,    83,
      84,    85,    86,    87,    88,    73,     0,    81,     0,     0,
       0,     0,   276,     0,     0,    83,    84,    85,    86,    87,
      88,    73,     0,     0,    74,    75,    76,    77,    78,     0,
      79,    80,     0,     0,     0,     0,     0,     0,     0,     0,
      74,    75,    76,    77,    78,     0,    79,    80,     0,     0,
       0,     0,     0,     0,   120,     0,     0,     0,     0,     0,
       0,     0,    83,    84,    85,    86,    87,    88,    73,     0,
     122,     0,     0,     0,     0,     0,     0,     0,    83,    84,
      85,    86,    87,    88,     0,     0,     0,    74,    75,    76,
      77,    78,     0,    79,    80,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    81,     0,     0,
       0,     0,     0,     0,     0,    83,    84,    85,    86,    87,
      88,     1,     2,     3,     4,     0,     5,     0,     6,     0,
       7,     8,     9,    10,     0,    11,     0,    12,     0,     0,
      13,     0,     0,    14,    15,     0,    16,     0,    17,     0,
      18,     0,    19,    20,    48,     0,    21,     1,     2,     3,
       4,     0,     5,     0,     6,     0,     7,     8,     9,    10,
       0,    11,     0,    12,   303,     0,    13,     0,     0,    14,
      15,     0,    16,     0,    17,     0,    18,     0,    19,    20,
       0,     0,    21,     1,     2,     3,     4,     0,     5,     0,
       6,     0,     7,     8,     9,    10,     0,    11,     0,    12,
       0,     0,    13,     0,     0,    14,    15,     0,    16,     0,
      17,     0,    18,     0,    19,    20,     0,     0,    21,     2,
       3,     4,     0,     0,     0,     6,     0,     7,     8,     9,
      10,     0,    11,     0,    12,     0,     0,    13,     0,     0,
       0,    15,     0,     0,     0,    17,     0,    18,     0,    19,
      20
};

static const yytype_int16 yycheck[] =
{
       0,    73,    81,     0,    62,   117,    23,    79,    80,   134,
      92,   131,   208,    63,   310,    40,    40,    40,    35,   131,
      92,    50,    51,    76,    77,    55,    81,    24,    25,    29,
      27,    28,    29,    72,    40,    74,    71,    70,    75,    72,
      40,   120,    77,   122,   175,   117,    70,    70,    80,    81,
      57,    76,   348,    92,    75,    79,    63,    86,    87,   131,
      90,    61,   112,   142,   360,   120,     5,   122,   239,    72,
      40,    74,   127,    71,   129,    14,   158,   159,   160,    77,
      19,   165,   166,   167,   168,    36,   158,   159,   160,   161,
     162,   163,   164,   165,   166,   167,   168,   169,   170,   171,
     172,   173,    79,    54,    71,   112,   237,    84,    85,   116,
      77,   242,    63,   110,    93,    71,   247,    71,    71,   290,
     240,    77,   204,    77,    77,    77,   257,   134,   240,   325,
      81,    72,   204,    74,   141,    76,    72,    40,    74,    73,
      76,    71,   313,    77,    79,    45,    46,    47,   155,    25,
      78,    27,    28,    54,   127,   280,   129,   120,    89,   122,
      92,   112,   179,   235,   236,   116,   337,   338,   240,   120,
      70,   122,    72,    92,    74,     5,   127,    88,   129,   186,
      48,    49,   189,    75,    14,    73,   357,    73,   319,    19,
      71,    21,    40,   200,    40,    25,    52,    53,   329,    40,
     331,    76,    77,    76,    77,   336,    90,   286,   339,    71,
      40,    41,    42,    43,    44,   294,    46,    47,   297,   161,
     162,   352,    77,   163,   164,   169,   170,   358,    40,    73,
      73,    73,   344,    71,   365,   186,   315,    71,    73,    71,
      70,   299,    93,    73,    77,    70,    40,    70,    78,    79,
      80,    81,    82,    83,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    93,    91,    70,    91,    77,   266,
     349,    76,   344,   280,    76,   282,    93,    73,    73,    93,
      91,    70,    75,    93,    91,    93,    18,    93,    76,    92,
     290,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    70,    30,    31,
      32,    33,    34,    35,    71,    93,    38,    37,    40,    41,
      42,    43,    44,    93,    46,    47,    71,   173,   235,    56,
     171,   236,   129,   119,   172,    42,    53,   276,   266,    29,
     136,   322,   301,    -1,    -1,    -1,    -1,    -1,    70,    -1,
      -1,    -1,    -1,    75,    -1,    -1,    78,    79,    80,    81,
      82,    83,    -1,     3,     4,     5,     6,    -1,     8,    -1,
      10,    93,    12,    13,    14,    15,    -1,    17,    -1,    19,
      -1,    -1,    22,    -1,    -1,    25,    26,    -1,    28,    -1,
      30,    -1,    32,    -1,    34,    35,    -1,    -1,    38,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    30,    31,    32,    33,
      34,    35,    -1,    -1,    38,    75,    40,    41,    42,    43,
      44,    -1,    46,    47,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    92,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    -1,
      -1,    75,    -1,    -1,    78,    79,    80,    81,    82,    83,
       3,     4,     5,     6,    -1,     8,    -1,    10,    -1,    12,
      13,    14,    15,    -1,    17,    -1,    19,    -1,    21,    22,
      -1,    -1,    25,    26,    -1,    28,    -1,    30,    -1,    32,
      -1,    34,    35,    -1,    -1,    38,    -1,    40,    41,    42,
      43,    44,    -1,    46,    47,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    78,    79,    80,    81,    82,
      83,     4,     5,     6,    -1,    -1,    -1,    10,    -1,    12,
      13,    14,    15,    -1,    17,    -1,    19,    -1,    21,    22,
      -1,    -1,    -1,    26,    -1,    -1,    -1,    30,    -1,    32,
      -1,    34,    35,    -1,    -1,    -1,    -1,    40,    41,    42,
      43,    44,    -1,    46,    47,    -1,     5,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    14,    -1,    -1,    -1,    -1,
      19,    -1,    21,    -1,    -1,    -1,    25,    70,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    78,    79,    80,    81,    82,
      83,    40,    41,    42,    43,    44,    -1,    46,    47,    -1,
       5,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    14,
      -1,    -1,    -1,    -1,    19,    -1,    21,    -1,    -1,    -1,
      -1,    70,    -1,    -1,    73,    -1,    -1,    -1,    -1,    78,
      79,    80,    81,    82,    83,    40,    41,    42,    43,    44,
      -1,    46,    47,    -1,    -1,    -1,     7,    -1,     9,    -1,
      11,    -1,    -1,    -1,    -1,    16,    -1,    18,    -1,    20,
      21,    -1,    23,    24,    -1,    70,    27,    -1,    -1,    -1,
      31,    -1,    33,    78,    79,    80,    81,    82,    83,    40,
      41,    42,    43,    44,    -1,    46,    47,   295,   296,    -1,
     298,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,    -1,    -1,    -1,    -1,    70,
      -1,    -1,    -1,    -1,    75,    -1,    -1,    78,    79,    80,
      81,    82,    83,    -1,    -1,   333,    -1,    -1,    -1,    -1,
      -1,    -1,   340,    -1,    -1,    -1,    -1,    -1,    -1,   347,
      -1,    -1,    -1,   351,    -1,     3,     4,     5,     6,    -1,
       8,    -1,    10,   361,    12,    13,    14,    15,   366,    17,
      -1,    19,    21,    -1,    22,    -1,    -1,    25,    26,    -1,
      28,    -1,    30,    -1,    32,    -1,    34,    35,    21,    -1,
      38,    40,    41,    42,    43,    44,    -1,    46,    47,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    40,    41,    42,
      43,    44,    -1,    46,    47,    -1,    -1,    -1,    -1,    -1,
      -1,    70,    -1,    71,    -1,    -1,    75,    -1,    -1,    78,
      79,    80,    81,    82,    83,    21,    -1,    70,    -1,    -1,
      -1,    -1,    75,    -1,    -1,    78,    79,    80,    81,    82,
      83,    21,    -1,    -1,    40,    41,    42,    43,    44,    -1,
      46,    47,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      40,    41,    42,    43,    44,    -1,    46,    47,    -1,    -1,
      -1,    -1,    -1,    -1,    70,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    78,    79,    80,    81,    82,    83,    21,    -1,
      70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    78,    79,
      80,    81,    82,    83,    -1,    -1,    -1,    40,    41,    42,
      43,    44,    -1,    46,    47,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    78,    79,    80,    81,    82,
      83,     3,     4,     5,     6,    -1,     8,    -1,    10,    -1,
      12,    13,    14,    15,    -1,    17,    -1,    19,    -1,    -1,
      22,    -1,    -1,    25,    26,    -1,    28,    -1,    30,    -1,
      32,    -1,    34,    35,     0,    -1,    38,     3,     4,     5,
       6,    -1,     8,    -1,    10,    -1,    12,    13,    14,    15,
      -1,    17,    -1,    19,    56,    -1,    22,    -1,    -1,    25,
      26,    -1,    28,    -1,    30,    -1,    32,    -1,    34,    35,
      -1,    -1,    38,     3,     4,     5,     6,    -1,     8,    -1,
      10,    -1,    12,    13,    14,    15,    -1,    17,    -1,    19,
      -1,    -1,    22,    -1,    -1,    25,    26,    -1,    28,    -1,
      30,    -1,    32,    -1,    34,    35,    -1,    -1,    38,     4,
       5,     6,    -1,    -1,    -1,    10,    -1,    12,    13,    14,
      15,    -1,    17,    -1,    19,    -1,    -1,    22,    -1,    -1,
      -1,    26,    -1,    -1,    -1,    30,    -1,    32,    -1,    34,
      35
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     4,     5,     6,     8,    10,    12,    13,    14,
      15,    17,    19,    22,    25,    26,    28,    30,    32,    34,
      35,    38,   119,   121,   125,   126,   129,   133,   134,   164,
     165,   166,    40,   130,    40,    70,    79,   120,   123,   124,
     135,   137,   139,   121,   122,   122,   122,   122,     0,   165,
      75,   135,   133,   138,   140,    93,    77,    92,   119,   121,
     167,   168,    70,    72,   137,    40,   131,   132,    71,   139,
     133,   124,   135,    21,    40,    41,    42,    43,    44,    46,
      47,    70,    75,    78,    79,    80,    81,    82,    83,    95,
      96,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,   109,   112,   113,   114,   115,   146,   136,   119,    40,
     136,   144,    25,    73,    79,   115,   140,    92,    76,    77,
      70,    99,    70,    99,    99,   115,   117,   126,   127,   133,
     145,    72,    74,   147,   148,   149,   150,   151,    45,    46,
      47,    70,    72,    74,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    92,   116,    99,   101,    79,    84,
      85,    80,    81,    48,    49,    50,    51,    86,    87,    52,
      53,    78,    88,    89,    54,    55,   111,    75,    71,   121,
     141,   142,   143,    71,    77,   115,   140,    73,    73,    25,
      73,    79,   115,   114,   118,    76,   132,   145,   145,    71,
      77,   127,   128,   128,    71,   118,    40,    76,    77,   146,
      92,   151,    40,    97,    98,   115,   117,    40,   115,   101,
     101,   101,   102,   102,   103,   103,   104,   104,   104,   104,
     105,   105,   106,   107,   108,   110,   110,    90,     7,     9,
      11,    16,    18,    20,    23,    24,    27,    31,    33,    40,
      75,   117,   119,   152,   153,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   135,    71,    77,    40,    73,   115,
     115,    73,    73,    71,    71,   115,    75,   101,    73,    76,
     148,    71,    77,    73,   109,   112,   110,    93,   160,   118,
      70,   110,    40,    93,    70,    91,   110,    70,    91,   154,
      76,   110,    93,    56,   143,    73,    73,   147,   146,   115,
     117,    93,    91,   119,   160,    70,    93,   117,   152,   152,
     117,   152,   136,   158,    76,    77,   111,   152,   160,    93,
     117,    71,   110,    71,   156,    76,    91,    93,   110,    71,
     110,    18,   152,    76,   110,   160,   160,   110,   152,    70,
     114,    71,    93,   152,   111,   117,   152,   110,    37,    71,
     160,   110,    93,   111,   152,    71,   110,   152
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    94,    95,    95,    95,    95,    95,    95,    96,    96,
      96,    96,    96,    96,    96,    96,    96,    97,    97,    98,
      98,    99,    99,    99,    99,    99,    99,   100,   100,   100,
     100,   100,   100,   101,   101,   102,   102,   102,   102,   103,
     103,   103,   104,   104,   104,   105,   105,   105,   105,   105,
     106,   106,   106,   107,   107,   108,   108,   109,   109,   110,
     111,   112,   112,   113,   113,   114,   114,   115,   115,   116,
     116,   116,   116,   116,   116,   116,   116,   116,   116,   116,
     117,   117,   118,   119,   120,   120,   121,   121,   121,   121,
     122,   122,   123,   123,   124,   124,   125,   125,   125,   125,
     126,   126,   126,   126,   126,   126,   126,   126,   126,   126,
     126,   126,   126,   127,   127,   128,   128,   129,   129,   129,
     130,   130,   131,   131,   132,   132,   133,   133,   133,   134,
     135,   135,   136,   137,   137,   137,   137,   137,   137,   137,
     137,   137,   137,   137,   137,   137,   137,   138,   138,   139,
     139,   140,   140,   141,   141,   142,   142,   143,   143,   144,
     144,   145,   146,   146,   146,   147,   147,   148,   148,   149,
     150,   150,   151,   151,   152,   152,   152,   152,   152,   152,
     153,   153,   153,   154,   155,   156,   156,   157,   157,   158,
     158,   159,   160,   160,   161,   161,   161,   162,   162,   162,
     162,   163,   163,   163,   163,   164,   164,   165,   165,   166,
     167,   167,   168,   168
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     1,     3,     1,     4,
       4,     3,     3,     2,     2,     6,     7,     1,     0,     1,
       3,     1,     2,     2,     2,     2,     4,     1,     1,     1,
       1,     1,     1,     1,     4,     1,     3,     3,     3,     1,
       3,     3,     1,     3,     3,     1,     3,     3,     3,     3,
       1,     3,     3,     1,     3,     1,     3,     1,     3,     0,
       0,     1,     4,     1,     4,     1,     9,     1,     3,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     3,     1,     3,     1,     0,     2,     2,     2,     2,
       1,     0,     1,     3,     1,     3,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     2,     2,     1,     0,     5,     6,     2,
       1,     0,     1,     3,     1,     3,     1,     1,     1,     1,
       2,     1,     0,     1,     3,     5,     4,     4,     3,     6,
       5,     6,     5,     4,     5,     4,     4,     1,     0,     2,
       3,     1,     2,     1,     3,     1,     3,     2,     1,     1,
       3,     1,     1,     3,     4,     2,     4,     1,     0,     2,
       1,     2,     3,     2,     1,     1,     1,     1,     1,     1,
       3,     4,     3,     0,     5,     1,     0,     1,     3,     1,
       1,     2,     1,     0,     7,    10,     5,     7,     9,    13,
       8,     3,     2,     2,     3,     1,     2,     1,     1,     7,
       1,     0,     1,     2
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YYUSE (yyoutput);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyo, yytoknum[yytype], *yyvaluep);
# endif
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyo, yytype, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[+yyssp[yyi + 1 - yynrhs]],
                       &yyvsp[(yyi + 1) - (yynrhs)]
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
#  else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                yy_state_t *yyssp, int yytoken)
{
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Actual size of YYARG. */
  int yycount = 0;
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[+*yyssp];
      YYPTRDIFF_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
      yysize = yysize0;
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYPTRDIFF_T yysize1
                    = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
                    yysize = yysize1;
                  else
                    return 2;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    /* Don't count the "%s"s in the final size, but reserve room for
       the terminator.  */
    YYPTRDIFF_T yysize1 = yysize + (yystrlen (yyformat) - 2 * yycount) + 1;
    if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
      yysize = yysize1;
    else
      return 2;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss;
    yy_state_t *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYPTRDIFF_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    goto yyexhaustedlab;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
# undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2:
#line 171 "bison2.y"
                        { yyreduce("primary_expression --> IDENTIFIER");
                            (yyval.expression) = new Expression();
                            (yyval.expression)->symbol = (yyvsp[0].symbol);
                            (yyval.expression)->type = Expression::NONBOOLEAN;
                          }
#line 1921 "y.tab.c"
    break;

  case 3:
#line 177 "bison2.y"
                        { yyreduce("primary_expression --> INTEGER_CONSTANT");
                            (yyval.expression) = new Expression();
                            (yyval.expression)->symbol = gentemp(SymbolType::INT, toString((yyvsp[0].intVal)));
                            emit("=",(yyval.expression)->symbol->name, (yyvsp[0].intVal));
                        }
#line 1931 "y.tab.c"
    break;

  case 4:
#line 183 "bison2.y"
                        { 
                            yyinfo("primary_expression => FLOATING_CONSTANT");
                            (yyval.expression) = new Expression();
                            (yyval.expression)->symbol = gentemp(SymbolType::FLOAT, toString((yyvsp[0].floatVal)));
                            emit("=", (yyval.expression)->symbol->name, (yyvsp[0].floatVal));
                         }
#line 1942 "y.tab.c"
    break;

  case 5:
#line 190 "bison2.y"
                        { 
                            yyinfo("primary_expression => CHARACTER_CONSTANT"); 
                            (yyval.expression) = new Expression();
                            (yyval.expression)->symbol = gentemp(SymbolType::CHAR, (yyvsp[0].charName));
                            emit("=", (yyval.expression)->symbol->name, (yyvsp[0].charName));
                        }
#line 1953 "y.tab.c"
    break;

  case 6:
#line 197 "bison2.y"
                        {
                            yyinfo("primary_expression => STRING_LITERAL"); 
                            (yyval.expression) = new Expression();
		                    (yyval.expression)->symbol = gentemp(SymbolType::POINTER, (yyvsp[0].stringName));
		                    (yyval.expression)->symbol->type->arrayType = new SymbolType(SymbolType::CHAR);
                        }
#line 1964 "y.tab.c"
    break;

  case 7:
#line 204 "bison2.y"
                        { 
                            yyinfo("primary_expression => ( expression )"); 
                            (yyval.expression) = (yyvsp[-1].expression);
                         }
#line 1973 "y.tab.c"
    break;

  case 8:
#line 212 "bison2.y"
                        { 
                            yyinfo("postfix_expression => primary_expression"); 
                            (yyval.array) = new Array();
                            (yyval.array)->symbol = (yyvsp[0].expression)->symbol;
                            (yyval.array)->temp = (yyval.array)->symbol;
                            (yyval.array)->subArrayType = (yyvsp[0].expression)->symbol->type;
                         }
#line 1985 "y.tab.c"
    break;

  case 9:
#line 220 "bison2.y"
                        { 

                            yyinfo("postfix_expression => postfix_expression [ expression ]"); 
                            (yyval.array) = new Array();
                            (yyval.array)->symbol = (yyvsp[-3].array)->symbol;    // same symbol as before
                            (yyval.array)->subArrayType = (yyvsp[-3].array)->subArrayType->arrayType; // as we are indexing we go one level deeper
                            (yyval.array)->temp = gentemp(SymbolType::INT); // temporary to compute location
                            (yyval.array)->type = Array::ARRAY;    // type will be array

                            if((yyvsp[-3].array)->type == Array::ARRAY) {
                                // postfix_expression is already array so multiply size of subarray with expression and add
                                Symbol *sym = gentemp(SymbolType::INT);
                                emit("*", sym->name, (yyvsp[-1].expression)->symbol->name, toString((yyval.array)->subArrayType->getSize()));
                                emit("+", (yyval.array)->temp->name, (yyvsp[-3].array)->temp->name, sym->name);
                            } else {
                                emit("*", (yyval.array)->temp->name, (yyvsp[-1].expression)->symbol->name, toString((yyval.array)->subArrayType->getSize()));
                            }


                         }
#line 2010 "y.tab.c"
    break;

  case 10:
#line 241 "bison2.y"
                        { 

                            yyinfo("postfix_expression => postfix_expression ( argument_expression_list_opt )"); 
                            (yyval.array) = new Array();
                            (yyval.array)->symbol = gentemp((yyvsp[-3].array)->symbol->type->type);
                            emit("call", (yyval.array)->symbol->name, (yyvsp[-3].array)->symbol->name, toString((yyvsp[-1].parameterCount)));

                         }
#line 2023 "y.tab.c"
    break;

  case 11:
#line 250 "bison2.y"
                        { 
                            
                            yyinfo("postfix_expression => postfix_expression -> IDENTIFIER"); 

                        }
#line 2033 "y.tab.c"
    break;

  case 12:
#line 256 "bison2.y"
                        { 
                           yyinfo("postfix_expression => postfix_expression -> IDENTIFIER"); 
                        }
#line 2041 "y.tab.c"
    break;

  case 13:
#line 260 "bison2.y"
                        { 

                            yyinfo("postfix_expression => postfix_expression ++");
                            (yyval.array) = new Array();
                            (yyval.array)->symbol = gentemp((yyvsp[-1].array)->symbol->type->type);
                            emit("=", (yyval.array)->symbol->name, (yyvsp[-1].array)->symbol->name);
                            emit("+", (yyvsp[-1].array)->symbol->name, (yyvsp[-1].array)->symbol->name, toString(1)); 

                         }
#line 2055 "y.tab.c"
    break;

  case 14:
#line 270 "bison2.y"
                        { 

                            yyinfo("postfix_expression => postfix_expression --"); 
                            (yyval.array) = new Array();
                            (yyval.array)->symbol = gentemp((yyvsp[-1].array)->symbol->type->type);
                            emit("=", (yyval.array)->symbol->name, (yyvsp[-1].array)->symbol->name);
                            emit("-", (yyvsp[-1].array)->symbol->name, (yyvsp[-1].array)->symbol->name, toString(1));

                         }
#line 2069 "y.tab.c"
    break;

  case 15:
#line 280 "bison2.y"
                        { 
                            yyinfo("postfix_expression => ( type_name ) { initialiser_list }"); 
                         }
#line 2077 "y.tab.c"
    break;

  case 16:
#line 284 "bison2.y"
                        { 
                            yyinfo("postfix_expression => ( type_name ) { initialiser_list , }"); 
                         }
#line 2085 "y.tab.c"
    break;

  case 17:
#line 291 "bison2.y"
                                    { 
                                        yyinfo("argument_expression_list_opt => argument_expression_list"); 
                                        (yyval.parameterCount) = (yyvsp[0].parameterCount);
                                     }
#line 2094 "y.tab.c"
    break;

  case 18:
#line 296 "bison2.y"
                                    { 
                                        yyinfo("argument_expression_list_opt => e");
                                        (yyval.parameterCount) = 0;
                                     }
#line 2103 "y.tab.c"
    break;

  case 19:
#line 307 "bison2.y"
                                { 
                                    // first param, initialise param count to 1
                                    yyinfo("argument_expression_list => assignment_expression"); 
                                    emit("param", (yyvsp[0].expression)->symbol->name);
                                    (yyval.parameterCount) = 1;
                                }
#line 2114 "y.tab.c"
    break;

  case 20:
#line 314 "bison2.y"
                                { 
                                    // one new param, add 1 to param count
                                    yyinfo("argument_expression_list => argument_expression_list , assignment_expression");
                                    emit("param", (yyvsp[0].expression)->symbol->name);
                                    (yyval.parameterCount) = (yyvsp[-2].parameterCount) + 1; 
                                }
#line 2125 "y.tab.c"
    break;

  case 21:
#line 324 "bison2.y"
                        { 
                            yyinfo("unary_expression => postfix_expression"); 
                            (yyval.array) = (yyvsp[0].array);
                        }
#line 2134 "y.tab.c"
    break;

  case 22:
#line 329 "bison2.y"
                        { 
                            // pre increment, no new temporary simply add 1
                            yyinfo("unary_expression => ++ unary_expression"); 
                            (yyval.array) = (yyvsp[0].array);
                            emit("+", (yyvsp[0].array)->symbol->name, (yyvsp[0].array)->symbol->name, toString(1));
                        }
#line 2145 "y.tab.c"
    break;

  case 23:
#line 336 "bison2.y"
                        { 
                            // pre decrement, no new temporary simply subtract 1
                            yyinfo("unary_expression => -- unary_expression"); 
                            (yyval.array) = (yyvsp[0].array);
                            emit("-", (yyvsp[0].array)->symbol->name, (yyvsp[0].array)->symbol->name, toString(1));
                        }
#line 2156 "y.tab.c"
    break;

  case 24:
#line 343 "bison2.y"
                        { 
                            yyinfo("unary_expression => unary_operator cast_expression");
                            if(strcmp((yyvsp[-1].unaryOperator), "&") == 0) {
                                // addressing, this generates a pointer, the subArray type will thus be the symbol type of the cast_expression
                                (yyval.array) = new Array();
                                (yyval.array)->symbol = gentemp(SymbolType::POINTER);
                                (yyval.array)->symbol->type->arrayType = (yyvsp[0].array)->symbol->type;
                                emit("=&", (yyval.array)->symbol->name, (yyvsp[0].array)->symbol->name);
                            } else if(strcmp((yyvsp[-1].unaryOperator), "*") == 0) {
                                // dereferncing, this generates a pointer, a new temporary generated with type as the subarray type of the cast_expression
                                // the subArray type will thus be one level deeper that of the cast_expression
                                (yyval.array) = new Array();
                                (yyval.array)->symbol = (yyvsp[0].array)->symbol;
                                (yyval.array)->temp = gentemp((yyvsp[0].array)->temp->type->arrayType->type);
                                (yyval.array)->temp->type->arrayType = (yyvsp[0].array)->temp->type->arrayType->arrayType;
                                (yyval.array)->type = Array::POINTER;
                                emit("=*", (yyval.array)->temp->name, (yyvsp[0].array)->temp->name);
                            } else if(strcmp((yyvsp[-1].unaryOperator), "+") == 0) {
                                (yyval.array) = (yyvsp[0].array);
                            } else { // for -, ~ and !
                                // simply apply the operator on cast_expression
                                (yyval.array) = new Array();
                                (yyval.array)->symbol = gentemp((yyvsp[0].array)->symbol->type->type);
                                emit((yyvsp[-1].unaryOperator), (yyval.array)->symbol->name, (yyvsp[0].array)->symbol->name);
                            }
                        }
#line 2187 "y.tab.c"
    break;

  case 25:
#line 370 "bison2.y"
                        { 
                            yyinfo("unary_expression => sizeof unary_expression"); 
                        }
#line 2195 "y.tab.c"
    break;

  case 26:
#line 374 "bison2.y"
                        { 
                            yyinfo("unary_expression => sizeof ( type_name )"); 
                        }
#line 2203 "y.tab.c"
    break;

  case 27:
#line 385 "bison2.y"
                    { 
                        yyinfo("unary_operator => &"); 
                        (yyval.unaryOperator) = strdup("&"); 
                    }
#line 2212 "y.tab.c"
    break;

  case 28:
#line 390 "bison2.y"
                    { 
                        yyinfo("unary_operator => *"); 
                        (yyval.unaryOperator) = strdup("*"); 
                    }
#line 2221 "y.tab.c"
    break;

  case 29:
#line 395 "bison2.y"
                    { 
                        yyinfo("unary_operator => +"); 
                        (yyval.unaryOperator) = strdup("+"); 
                    }
#line 2230 "y.tab.c"
    break;

  case 30:
#line 400 "bison2.y"
                    { 
                        yyinfo("unary_operator => -"); 
                        (yyval.unaryOperator) = strdup("=-"); 
                    }
#line 2239 "y.tab.c"
    break;

  case 31:
#line 405 "bison2.y"
                    { 
                        yyinfo("unary_operator => ~"); 
                        (yyval.unaryOperator) = strdup("~"); 
                    }
#line 2248 "y.tab.c"
    break;

  case 32:
#line 410 "bison2.y"
                    { 
                        yyinfo("unary_operator => !"); 
                        (yyval.unaryOperator) = strdup("!"); 
                    }
#line 2257 "y.tab.c"
    break;

  case 33:
#line 418 "bison2.y"
                    { 
                        yyinfo("cast_expression => unary_expression"); 
                        (yyval.array) = (yyvsp[0].array);
                    }
#line 2266 "y.tab.c"
    break;

  case 34:
#line 423 "bison2.y"
                    { 
                        yyinfo("cast_expression => ( type_name ) cast_expression"); 
                        (yyval.array) = new Array();
                        (yyval.array)->symbol = (yyvsp[0].array)->symbol->convert(currentType);
                    }
#line 2276 "y.tab.c"
    break;

  case 35:
#line 442 "bison2.y"
                                { 
                                    SymbolType *baseType = (yyvsp[0].array)->symbol->type;
                                    while(baseType->arrayType)
                                        baseType = baseType->arrayType;
                                    yyinfo("multiplicative_expression => cast_expression"); 
                                    (yyval.expression) = new Expression();
                                    if((yyvsp[0].array)->type == Array::ARRAY) {
                                        (yyval.expression)->symbol = gentemp(baseType->type);
                                        emit("=[]", (yyval.expression)->symbol->name, (yyvsp[0].array)->symbol->name, (yyvsp[0].array)->temp->name);
                                    } else if((yyvsp[0].array)->type == Array::POINTER) {
                                        (yyval.expression)->symbol = (yyvsp[0].array)->temp;
                                    } else {
                                        (yyval.expression)->symbol = (yyvsp[0].array)->symbol;
                                    }
                                }
#line 2296 "y.tab.c"
    break;

  case 36:
#line 458 "bison2.y"
                                { 
                                    SymbolType *baseType = (yyvsp[0].array)->symbol->type;
                                    while(baseType->arrayType)
                                        baseType = baseType->arrayType;
                                    Symbol *temp;
                                    if((yyvsp[0].array)->type == Array::ARRAY) {
                                        temp = gentemp(baseType->type);
                                        emit("=[]", temp->name, (yyvsp[0].array)->symbol->name, (yyvsp[0].array)->temp->name);
                                    } else if((yyvsp[0].array)->type == Array::POINTER) {
                                        temp = (yyvsp[0].array)->temp;
                                    } else {
                                        temp = (yyvsp[0].array)->symbol;
                                    }
                                    yyinfo("multiplicative_expression => multiplicative_expression * cast_expression"); 
                                    if(typeCheck((yyvsp[-2].expression)->symbol, temp)) {
                                        (yyval.expression) = new Expression();
                                        (yyval.expression)->symbol = gentemp((yyvsp[-2].expression)->symbol->type->type);
                                        emit("*", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, temp->name);
                                    } else {
                                        yyerror("Type error.");
                                    }
                                }
#line 2323 "y.tab.c"
    break;

  case 37:
#line 481 "bison2.y"
                                { 
                                    SymbolType *baseType = (yyvsp[0].array)->symbol->type;
                                    while(baseType->arrayType)
                                        baseType = baseType->arrayType;
                                    Symbol *temp;
                                    if((yyvsp[0].array)->type == Array::ARRAY) {
                                        temp = gentemp(baseType->type);
                                        emit("=[]", temp->name, (yyvsp[0].array)->symbol->name, (yyvsp[0].array)->temp->name);
                                    } else if((yyvsp[0].array)->type == Array::POINTER) {
                                        temp = (yyvsp[0].array)->temp;
                                    } else {
                                        temp = (yyvsp[0].array)->symbol;
                                    }
                                    yyinfo("multiplicative_expression => multiplicative_expression / cast_expression");
                                    if(typeCheck((yyvsp[-2].expression)->symbol, temp)) {
                                        (yyval.expression) = new Expression();
                                        (yyval.expression)->symbol = gentemp((yyvsp[-2].expression)->symbol->type->type);
                                        emit("/", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, temp->name);
                                    } else {
                                        yyerror("Type error.");
                                    }
                                }
#line 2350 "y.tab.c"
    break;

  case 38:
#line 504 "bison2.y"
                                { 
                                    SymbolType *baseType = (yyvsp[0].array)->symbol->type;
                                    while(baseType->arrayType)
                                        baseType = baseType->arrayType;
                                    Symbol *temp;
                                    if((yyvsp[0].array)->type == Array::ARRAY) {
                                        temp = gentemp(baseType->type);
                                        emit("=[]", temp->name, (yyvsp[0].array)->symbol->name, (yyvsp[0].array)->temp->name);
                                    } else if((yyvsp[0].array)->type == Array::POINTER) {
                                        temp = (yyvsp[0].array)->temp;
                                    } else {
                                        temp = (yyvsp[0].array)->symbol;
                                    }
                                    yyinfo("multiplicative_expression => multiplicative_expression % cast_expression"); 
                                    if(typeCheck((yyvsp[-2].expression)->symbol, temp)) {
                                        (yyval.expression) = new Expression();
                                        (yyval.expression)->symbol = gentemp((yyvsp[-2].expression)->symbol->type->type);
                                        emit("%", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, temp->name);
                                    } else {
                                        yyerror("Type error.");
                                    }
                                }
#line 2377 "y.tab.c"
    break;

  case 39:
#line 530 "bison2.y"
                        { 
                            yyinfo("additive_expression => multiplicative_expression"); 
                            (yyval.expression) = (yyvsp[0].expression);
                        }
#line 2386 "y.tab.c"
    break;

  case 40:
#line 535 "bison2.y"
                        { 
                            yyinfo("additive_expression => additive_expression + multiplicative_expression"); 
                            if(typeCheck((yyvsp[-2].expression)->symbol, (yyvsp[0].expression)->symbol)) {
                                (yyval.expression) = new Expression();
                                (yyval.expression)->symbol = gentemp((yyvsp[-2].expression)->symbol->type->type);
                                emit("+", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                            } else {
                                yyerror("Type error.");
                            }
                        }
#line 2401 "y.tab.c"
    break;

  case 41:
#line 546 "bison2.y"
                        { 
                            yyinfo("additive_expression => additive_expression - multiplicative_expression"); 
                            if(typeCheck((yyvsp[-2].expression)->symbol, (yyvsp[0].expression)->symbol)) {
                                (yyval.expression) = new Expression();
                                (yyval.expression)->symbol = gentemp((yyvsp[-2].expression)->symbol->type->type);
                                emit("-", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                            } else {
                                yyerror("Type error.");
                            }
                        }
#line 2416 "y.tab.c"
    break;

  case 42:
#line 560 "bison2.y"
                        { 
                            yyinfo("shift_expression => additive_expression");
                            (yyval.expression) = (yyvsp[0].expression);
                        }
#line 2425 "y.tab.c"
    break;

  case 43:
#line 565 "bison2.y"
                        { 
                            yyinfo("shift_expression => shift_expression << additive_expression"); 
                            if((yyvsp[0].expression)->symbol->type->type == SymbolType::INT) {
                                (yyval.expression) = new Expression();
                                (yyval.expression)->symbol = gentemp(SymbolType::INT);
                                emit("<<", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                            } else {
                                yyerror("Type error.");
                            }
                        }
#line 2440 "y.tab.c"
    break;

  case 44:
#line 576 "bison2.y"
                        { 
                            yyinfo("shift_expression => shift_expression >> additive_expression"); 
                            if((yyvsp[0].expression)->symbol->type->type == SymbolType::INT) {
                                (yyval.expression) = new Expression();
                                (yyval.expression)->symbol = gentemp(SymbolType::INT);
                                emit(">>", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                            } else {
                                yyerror("Type error.");
                            }
                        }
#line 2455 "y.tab.c"
    break;

  case 45:
#line 597 "bison2.y"
                            { 
                                yyinfo("relational_expression => shift_expression"); 
                                (yyval.expression) = (yyvsp[0].expression);
                            }
#line 2464 "y.tab.c"
    break;

  case 46:
#line 602 "bison2.y"
                            { 
                                yyinfo("relational_expression => relational_expression < shift_expression"); 
                                if(typeCheck((yyvsp[-2].expression)->symbol, (yyvsp[0].expression)->symbol)) {
                                    (yyval.expression) = new Expression();
                                    (yyval.expression)->type = Expression::BOOLEAN;
                                    (yyval.expression)->trueList = makeList(nextInstruction());
			                        (yyval.expression)->falseList = makeList(nextInstruction() + 1);
                                    emit("<", "", (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                                    emit("goto", "");
                                } else {
                                    yyerror("Type error.");
                                }
                            }
#line 2482 "y.tab.c"
    break;

  case 47:
#line 616 "bison2.y"
                            { 
                                yyinfo("relational_expression => relational_expression > shift_expression"); 
                                if(typeCheck((yyvsp[-2].expression)->symbol, (yyvsp[0].expression)->symbol)) {
                                    (yyval.expression) = new Expression();
                                    (yyval.expression)->type = Expression::BOOLEAN;
                                    (yyval.expression)->trueList = makeList(nextInstruction());
			                        (yyval.expression)->falseList = makeList(nextInstruction() + 1);
                                    emit(">", "", (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                                    emit("goto", "");
                                } else {
                                    yyerror("Type error.");
                                }
                            }
#line 2500 "y.tab.c"
    break;

  case 48:
#line 630 "bison2.y"
                            { 
                                yyinfo("relational_expression => relational_expression <= shift_expression"); 
                                if(typeCheck((yyvsp[-2].expression)->symbol, (yyvsp[0].expression)->symbol)) {
                                    (yyval.expression) = new Expression();
                                    (yyval.expression)->type = Expression::BOOLEAN;
                                    (yyval.expression)->trueList = makeList(nextInstruction());
			                        (yyval.expression)->falseList = makeList(nextInstruction() + 1);
                                    emit("<=", "", (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                                    emit("goto", "");
                                } else {
                                    yyerror("Type error.");
                                }
                            }
#line 2518 "y.tab.c"
    break;

  case 49:
#line 644 "bison2.y"
                            { 
                                yyinfo("relational_expression => relational_expression >= shift_expression"); 
                                if(typeCheck((yyvsp[-2].expression)->symbol, (yyvsp[0].expression)->symbol)) {
                                    (yyval.expression) = new Expression();
                                    (yyval.expression)->type = Expression::BOOLEAN;
                                    (yyval.expression)->trueList = makeList(nextInstruction());
			                        (yyval.expression)->falseList = makeList(nextInstruction() + 1);
                                    emit(">=", "", (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                                    emit("goto", "");
                                } else {
                                    yyerror("Type error.");
                                }
                            }
#line 2536 "y.tab.c"
    break;

  case 50:
#line 661 "bison2.y"
                        { 
                            yyinfo("equality_expression => relational_expression"); 
                            (yyval.expression) = (yyvsp[0].expression);
                        }
#line 2545 "y.tab.c"
    break;

  case 51:
#line 666 "bison2.y"
                        { 
                            yyinfo("equality_expression => equality_expression == relational_expression"); 
                            if(typeCheck((yyvsp[-2].expression)->symbol, (yyvsp[0].expression)->symbol)) {
                                (yyvsp[-2].expression)->toInt();
                                (yyvsp[0].expression)->toInt();
                                (yyval.expression) = new Expression();
                                (yyval.expression)->type = Expression::BOOLEAN;
                                (yyval.expression)->trueList = makeList(nextInstruction());
			                    (yyval.expression)->falseList = makeList(nextInstruction() + 1);
                                emit("==", "", (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                                emit("goto", "");
                            } else {
                                yyerror("Type error.");
                            }
                        }
#line 2565 "y.tab.c"
    break;

  case 52:
#line 682 "bison2.y"
                        { 
                            yyinfo("equality_expression => equality_expression != relational_expression"); 
                            if(typeCheck((yyvsp[-2].expression)->symbol, (yyvsp[0].expression)->symbol)) {
                                (yyvsp[-2].expression)->toInt();
                                (yyvsp[0].expression)->toInt();
                                (yyval.expression) = new Expression();
                                (yyval.expression)->type = Expression::BOOLEAN;
                                (yyval.expression)->trueList = makeList(nextInstruction());
			                    (yyval.expression)->falseList = makeList(nextInstruction() + 1);
                                emit("!=", "", (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                                emit("goto", "");
                            } else {
                                yyerror("Type error.");
                            }
                        }
#line 2585 "y.tab.c"
    break;

  case 53:
#line 710 "bison2.y"
                    { 
                        yyinfo("AND_expression => equality_expression"); 
                        (yyval.expression) = (yyvsp[0].expression);
                    }
#line 2594 "y.tab.c"
    break;

  case 54:
#line 715 "bison2.y"
                    { 
                        yyinfo("AND_expression => AND_expression & equality_expression"); 
                        (yyvsp[-2].expression)->toInt();
                        (yyvsp[0].expression)->toInt();
                        (yyval.expression) = new Expression();
                        (yyval.expression)->type = Expression::NONBOOLEAN;
                        (yyval.expression)->symbol = gentemp(SymbolType::INT);
                        emit("&", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                    }
#line 2608 "y.tab.c"
    break;

  case 55:
#line 728 "bison2.y"
                            { 
                                yyinfo("exclusive_OR_expression => AND_expression"); 
                                (yyval.expression) = (yyvsp[0].expression);
                            }
#line 2617 "y.tab.c"
    break;

  case 56:
#line 733 "bison2.y"
                            { 
                                yyinfo("exclusive_OR_expression => exclusive_OR_expression ^ AND_expression"); 
                                (yyvsp[-2].expression)->toInt();
                                (yyvsp[0].expression)->toInt();
                                (yyval.expression) = new Expression();
                                (yyval.expression)->type = Expression::NONBOOLEAN;
                                (yyval.expression)->symbol = gentemp(SymbolType::INT);
                                emit("^", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                            }
#line 2631 "y.tab.c"
    break;

  case 57:
#line 746 "bison2.y"
                            { 
                                yyinfo("inclusive_OR_expression => exclusive_OR_expression"); 
                                (yyval.expression) = (yyvsp[0].expression);
                            }
#line 2640 "y.tab.c"
    break;

  case 58:
#line 751 "bison2.y"
                            { 
                                yyinfo("inclusive_OR_expression => inclusive_OR_expression | exclusive_OR_expression"); 
                                (yyvsp[-2].expression)->toInt();
                                (yyvsp[0].expression)->toInt();
                                (yyval.expression) = new Expression();
                                (yyval.expression)->type = Expression::NONBOOLEAN;
                                (yyval.expression)->symbol = gentemp(SymbolType::INT);
                                emit("|", (yyval.expression)->symbol->name, (yyvsp[-2].expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                            }
#line 2654 "y.tab.c"
    break;

  case 59:
#line 770 "bison2.y"
        {
            yyinfo("M => epsilon");
            (yyval.instructionNumber) = nextInstruction();
        }
#line 2663 "y.tab.c"
    break;

  case 60:
#line 777 "bison2.y"
        {
            yyinfo("N => epsilon");
            (yyval.statement) = new Statement();
            (yyval.statement)->nextList = makeList(nextInstruction());
            emit("goto", "");
        }
#line 2674 "y.tab.c"
    break;

  case 61:
#line 815 "bison2.y"
                            { 
                                yyinfo("logical_AND_expression => inclusive_OR_expression"); 
                                (yyval.expression) = (yyvsp[0].expression);
                            }
#line 2683 "y.tab.c"
    break;

  case 62:
#line 820 "bison2.y"
                            { 
                                yyinfo("logical_AND_expression => logical_AND_expression && inclusive_OR_expression");
                                (yyvsp[-3].expression)->toBool();
                                (yyvsp[0].expression)->toBool();
                                (yyval.expression) = new Expression();
                                (yyval.expression)->type = Expression::BOOLEAN;
                                backpatch((yyvsp[-3].expression)->trueList, (yyvsp[-1].instructionNumber));
                                (yyval.expression)->trueList = (yyvsp[0].expression)->trueList;
                                (yyval.expression)->falseList = merge((yyvsp[-3].expression)->falseList, (yyvsp[0].expression)->falseList);
                            }
#line 2698 "y.tab.c"
    break;

  case 63:
#line 834 "bison2.y"
                            { 
                                yyinfo("logical_OR_expression => logical_AND_expression"); 
                                (yyval.expression) = (yyvsp[0].expression);
                            }
#line 2707 "y.tab.c"
    break;

  case 64:
#line 839 "bison2.y"
                            { 
                                yyinfo("logical_OR_expression => logical_OR_expression || logical_AND_expression"); 
                                (yyvsp[-3].expression)->toBool();
                                (yyvsp[0].expression)->toBool();
                                (yyval.expression) = new Expression();
                                (yyval.expression)->type = Expression::BOOLEAN;
                                backpatch((yyvsp[-3].expression)->falseList, (yyvsp[-1].instructionNumber));
                                (yyval.expression)->trueList = merge((yyvsp[-3].expression)->trueList, (yyvsp[0].expression)->trueList);
                                (yyval.expression)->falseList = (yyvsp[0].expression)->falseList;
                            }
#line 2722 "y.tab.c"
    break;

  case 65:
#line 853 "bison2.y"
                            { 
                                yyinfo("conditional_expression => logical_OR_expression"); 
                                (yyval.expression) = (yyvsp[0].expression);
                            }
#line 2731 "y.tab.c"
    break;

  case 66:
#line 858 "bison2.y"
                            { 
                                yyinfo("conditional_expression => logical_OR_expression ? expression : conditional_expression"); 
                                (yyval.expression)->symbol = gentemp((yyvsp[-4].expression)->symbol->type->type);
                                emit("=", (yyval.expression)->symbol->name, (yyvsp[0].expression)->symbol->name);
                                list<int> l = makeList(nextInstruction());
                                emit("goto", "");
                                backpatch((yyvsp[-3].statement)->nextList, nextInstruction());
                                emit("=", (yyval.expression)->symbol->name, (yyvsp[-4].expression)->symbol->name);
                                l = merge(l, makeList(nextInstruction()));
                                emit("goto", "");
                                backpatch((yyvsp[-7].statement)->nextList, nextInstruction());
                                (yyvsp[-8].expression)->toBool();
                                backpatch((yyvsp[-8].expression)->trueList, (yyvsp[-5].instructionNumber));
                                backpatch((yyvsp[-8].expression)->falseList, (yyvsp[-1].instructionNumber));
                                backpatch(l, nextInstruction());
                            }
#line 2752 "y.tab.c"
    break;

  case 67:
#line 878 "bison2.y"
                            { 
                                yyinfo("assignment_expression => conditional_expression"); 
                                (yyval.expression) = (yyvsp[0].expression);
                            }
#line 2761 "y.tab.c"
    break;

  case 68:
#line 883 "bison2.y"
                            { 
                                yyinfo("assignment_expression => unary_expression assignment_operator assignment_expression"); 
                                if((yyvsp[-2].array)->type == Array::ARRAY) {
                                    // assignment to array
                                    (yyvsp[0].expression)->symbol = (yyvsp[0].expression)->symbol->convert((yyvsp[-2].array)->subArrayType->type);
                                    emit("[]=", (yyvsp[-2].array)->symbol->name, (yyvsp[-2].array)->temp->name, (yyvsp[0].expression)->symbol->name);
                                } else if((yyvsp[-2].array)->type == Array::POINTER) {
                                    // assignment to pointer
                                    (yyvsp[0].expression)->symbol = (yyvsp[0].expression)->symbol->convert((yyvsp[-2].array)->temp->type->type);
                                    emit("*=", (yyvsp[-2].array)->temp->name, (yyvsp[0].expression)->symbol->name);
                                } else {
                                    // assignment to other
                                    (yyvsp[0].expression)->symbol = (yyvsp[0].expression)->symbol->convert((yyvsp[-2].array)->symbol->type->type);
			                        emit("=", (yyvsp[-2].array)->symbol->name, (yyvsp[0].expression)->symbol->name);
                                }
                                (yyval.expression) = (yyvsp[0].expression);
                            }
#line 2783 "y.tab.c"
    break;

  case 69:
#line 904 "bison2.y"
                        { 
                            yyinfo("assignment_operator => ="); 
                        }
#line 2791 "y.tab.c"
    break;

  case 70:
#line 908 "bison2.y"
                        { 
                            yyinfo("assignment_operator => *="); 
                        }
#line 2799 "y.tab.c"
    break;

  case 71:
#line 912 "bison2.y"
                        { 
                            yyinfo("assignment_operator => /="); 
                        }
#line 2807 "y.tab.c"
    break;

  case 72:
#line 916 "bison2.y"
                        { 
                            yyinfo("assignment_operator => %="); 
                        }
#line 2815 "y.tab.c"
    break;

  case 73:
#line 920 "bison2.y"
                        { 
                            yyinfo("assignment_operator => += "); 
                        }
#line 2823 "y.tab.c"
    break;

  case 74:
#line 924 "bison2.y"
                        { 
                            yyinfo("assignment_operator => -= "); 
                        }
#line 2831 "y.tab.c"
    break;

  case 75:
#line 928 "bison2.y"
                        { 
                            yyinfo("assignment_operator => <<="); 
                        }
#line 2839 "y.tab.c"
    break;

  case 76:
#line 932 "bison2.y"
                        { 
                            yyinfo("assignment_operator => >>="); 
                        }
#line 2847 "y.tab.c"
    break;

  case 77:
#line 936 "bison2.y"
                        { 
                            yyinfo("assignment_operator => &="); 
                        }
#line 2855 "y.tab.c"
    break;

  case 78:
#line 940 "bison2.y"
                        { 
                            yyinfo("assignment_operator => ^="); 
                        }
#line 2863 "y.tab.c"
    break;

  case 79:
#line 944 "bison2.y"
                        { 
                            yyinfo("assignment_operator => |="); 
                        }
#line 2871 "y.tab.c"
    break;

  case 80:
#line 951 "bison2.y"
                { 
                    yyinfo("expression => assignment_expression"); 
                    (yyval.expression) = (yyvsp[0].expression);
                }
#line 2880 "y.tab.c"
    break;

  case 81:
#line 956 "bison2.y"
                {
                     yyinfo("expression => expression , assignment_expression"); 
                }
#line 2888 "y.tab.c"
    break;

  case 82:
#line 963 "bison2.y"
                        {
                             yyinfo("constant_expression => conditional_expression"); 
                        }
#line 2896 "y.tab.c"
    break;

  case 83:
#line 972 "bison2.y"
                {
                     yyinfo("declaration => declaration_specifiers init_declarator_list_opt ;"); 
                }
#line 2904 "y.tab.c"
    break;

  case 84:
#line 979 "bison2.y"
                                {
                                     yyinfo("init_declarator_list_opt => init_declarator_list"); 
                                }
#line 2912 "y.tab.c"
    break;

  case 85:
#line 983 "bison2.y"
                                {
                                     yyinfo("init_declarator_list_opt => e"); 
                                }
#line 2920 "y.tab.c"
    break;

  case 86:
#line 990 "bison2.y"
                            {
                                 yyinfo("declaration_specifiers => storage_class_specifier declaration_specifiers_opt"); 
                            }
#line 2928 "y.tab.c"
    break;

  case 87:
#line 994 "bison2.y"
                            {
                                 yyinfo("declaration_specifiers => type_specifier declaration_specifiers_opt"); 
                            }
#line 2936 "y.tab.c"
    break;

  case 88:
#line 998 "bison2.y"
                            {
                                 yyinfo("declaration_specifiers => type_qualifier declaration_specifiers_opt"); 
                            }
#line 2944 "y.tab.c"
    break;

  case 89:
#line 1002 "bison2.y"
                            {
                                 yyinfo("declaration_specifiers => function_specifier declaration_specifiers_opt"); 
                            }
#line 2952 "y.tab.c"
    break;

  case 90:
#line 1009 "bison2.y"
                                {
                                     yyinfo("declaration_specifiers_opt => declaration_specifiers"); 
                                }
#line 2960 "y.tab.c"
    break;

  case 91:
#line 1013 "bison2.y"
                                {
                                     yyinfo("declaration_specifiers_opt => e"); 
                                }
#line 2968 "y.tab.c"
    break;

  case 92:
#line 1020 "bison2.y"
                            {
                                 yyinfo("init_declarator_list => init_declarator"); 
                            }
#line 2976 "y.tab.c"
    break;

  case 93:
#line 1024 "bison2.y"
                            {
                                 yyinfo("init_declarator_list => init_declarator_list , init_declarator"); 
                            }
#line 2984 "y.tab.c"
    break;

  case 94:
#line 1031 "bison2.y"
                    { 
                        yyinfo("init_declarator => declarator"); 
                        (yyval.symbol) = (yyvsp[0].symbol);
                    }
#line 2993 "y.tab.c"
    break;

  case 95:
#line 1036 "bison2.y"
                    { 
                        yyinfo("init_declarator => declarator = initialiser");
                        // if there is some initial value assign it 
                        if((yyvsp[0].symbol)->initialValue != "") 
                            (yyvsp[-2].symbol)->initialValue = (yyvsp[0].symbol)->initialValue;
                        // = assignment
		                emit("=", (yyvsp[-2].symbol)->name, (yyvsp[0].symbol)->name);
                    }
#line 3006 "y.tab.c"
    break;

  case 96:
#line 1048 "bison2.y"
                            {
                                 yyinfo("storage_class_specifier => extern"); 
                            }
#line 3014 "y.tab.c"
    break;

  case 97:
#line 1052 "bison2.y"
                            {
                                 yyinfo("storage_class_specifier => static"); 
                            }
#line 3022 "y.tab.c"
    break;

  case 98:
#line 1056 "bison2.y"
                            {
                                 yyinfo("storage_class_specifier => auto"); 
                            }
#line 3030 "y.tab.c"
    break;

  case 99:
#line 1060 "bison2.y"
                            {
                                 yyinfo("storage_class_specifier => register"); 
                            }
#line 3038 "y.tab.c"
    break;

  case 100:
#line 1067 "bison2.y"
                    { 
                        yyinfo("type_specifier => void");
                        currentType = SymbolType::VOID;
                    }
#line 3047 "y.tab.c"
    break;

  case 101:
#line 1072 "bison2.y"
                    { 
                        yyinfo("type_specifier => char"); 
                        currentType = SymbolType::CHAR;
                    }
#line 3056 "y.tab.c"
    break;

  case 102:
#line 1077 "bison2.y"
                    {
                         yyinfo("type_specifier => short"); 
                    }
#line 3064 "y.tab.c"
    break;

  case 103:
#line 1081 "bison2.y"
                    { 
                        yyinfo("type_specifier => int"); 
                        currentType = SymbolType::INT;
                    }
#line 3073 "y.tab.c"
    break;

  case 104:
#line 1086 "bison2.y"
                    {
                         yyinfo("type_specifier => long"); 
                    }
#line 3081 "y.tab.c"
    break;

  case 105:
#line 1090 "bison2.y"
                    { 
                        yyinfo("type_specifier => float"); 
                        currentType = SymbolType::FLOAT;
                    }
#line 3090 "y.tab.c"
    break;

  case 106:
#line 1095 "bison2.y"
                    {
                         yyinfo("type_specifier => double"); 
                    }
#line 3098 "y.tab.c"
    break;

  case 107:
#line 1099 "bison2.y"
                    {
                         yyinfo("type_specifier => signed"); 
                    }
#line 3106 "y.tab.c"
    break;

  case 108:
#line 1103 "bison2.y"
                    {
                         yyinfo("type_specifier => unsigned"); 
                    }
#line 3114 "y.tab.c"
    break;

  case 109:
#line 1107 "bison2.y"
                    {
                         yyinfo("type_specifier => _Bool"); 
                    }
#line 3122 "y.tab.c"
    break;

  case 110:
#line 1111 "bison2.y"
                    {
                         yyinfo("type_specifier => _Complex"); 
                    }
#line 3130 "y.tab.c"
    break;

  case 111:
#line 1115 "bison2.y"
                    {
                         yyinfo("type_specifier => _Imaginary"); 
                    }
#line 3138 "y.tab.c"
    break;

  case 112:
#line 1119 "bison2.y"
                    {
                         yyinfo("type_specifier => enum_specifier"); 
                    }
#line 3146 "y.tab.c"
    break;

  case 113:
#line 1126 "bison2.y"
                                { 
                                    yyinfo("specifier_qualifier_list => type_specifier specifier_qualifier_list_opt"); 
                                }
#line 3154 "y.tab.c"
    break;

  case 114:
#line 1130 "bison2.y"
                                { 
                                    yyinfo("specifier_qualifier_list => type_qualifier specifier_qualifier_list_opt"); 
                                }
#line 3162 "y.tab.c"
    break;

  case 115:
#line 1137 "bison2.y"
                                    { 
                                        yyinfo("specifier_qualifier_list_opt => specifier_qualifier_list"); 
                                    }
#line 3170 "y.tab.c"
    break;

  case 116:
#line 1141 "bison2.y"
                                    { 
                                        yyinfo("specifier_qualifier_list_opt => e"); 
                                    }
#line 3178 "y.tab.c"
    break;

  case 117:
#line 1148 "bison2.y"
                    { 
                        yyinfo("enum_specifier => enum identifier_opt { enumerator_list }"); 
                    }
#line 3186 "y.tab.c"
    break;

  case 118:
#line 1152 "bison2.y"
                    { 
                        yyinfo("enum_specifier => enum identifier_opt { enumerator_list , }"); 
                    }
#line 3194 "y.tab.c"
    break;

  case 119:
#line 1156 "bison2.y"
                    { 
                        yyinfo("enum_specifier => enum IDENTIFIER"); 
                    }
#line 3202 "y.tab.c"
    break;

  case 120:
#line 1163 "bison2.y"
                    { 
                        yyinfo("identifier_opt => IDENTIFIER"); 
                    }
#line 3210 "y.tab.c"
    break;

  case 121:
#line 1167 "bison2.y"
                    { 
                        yyinfo("identifier_opt => e"); 
                    }
#line 3218 "y.tab.c"
    break;

  case 122:
#line 1174 "bison2.y"
                    { 
                        yyinfo("enumerator_list => enumerator"); 
                    }
#line 3226 "y.tab.c"
    break;

  case 123:
#line 1178 "bison2.y"
                    { 
                        yyinfo("enumerator_list => enumerator_list , enumerator"); 
                    }
#line 3234 "y.tab.c"
    break;

  case 124:
#line 1185 "bison2.y"
                { 
                    yyinfo("enumerator => ENUMERATION_CONSTANT"); 
                }
#line 3242 "y.tab.c"
    break;

  case 125:
#line 1189 "bison2.y"
                { 
                    yyinfo("enumerator => ENUMERATION_CONSTANT = constant_expression"); 
                }
#line 3250 "y.tab.c"
    break;

  case 126:
#line 1196 "bison2.y"
                    { 
                        yyinfo("type_qualifier => const"); 
                    }
#line 3258 "y.tab.c"
    break;

  case 127:
#line 1200 "bison2.y"
                    { 
                        yyinfo("type_qualifier => restrict"); 
                    }
#line 3266 "y.tab.c"
    break;

  case 128:
#line 1204 "bison2.y"
                    { 
                        yyinfo("type_qualifier => volatile"); 
                    }
#line 3274 "y.tab.c"
    break;

  case 129:
#line 1211 "bison2.y"
                        { 
                            yyinfo("function_specifier => inline"); 
                        }
#line 3282 "y.tab.c"
    break;

  case 130:
#line 1218 "bison2.y"
                { 
                    yyinfo("declarator => pointer direct_declarator"); 
                    SymbolType *it = (yyvsp[-1].symbolType);
                    while(it->arrayType != NULL) 
                        it = it->arrayType;
                    it->arrayType = (yyvsp[0].symbol)->type;
                    (yyval.symbol) = (yyvsp[0].symbol)->update((yyvsp[-1].symbolType));
                }
#line 3295 "y.tab.c"
    break;

  case 131:
#line 1227 "bison2.y"
                { 
                    yyinfo("declarator => direct_declarator"); 
                }
#line 3303 "y.tab.c"
    break;

  case 132:
#line 1233 "bison2.y"
                    {
                        if(currentSymbol->nestedTable == NULL) {
                            changeTable(new SymbolTable(""));
                        }
                        else {
                            changeTable(currentSymbol->nestedTable);
                            emit("label", currentTable->name);
                        }
                    }
#line 3317 "y.tab.c"
    break;

  case 133:
#line 1250 "bison2.y"
                        { 
                            yyinfo("direct_declarator => IDENTIFIER"); 
                            (yyval.symbol) = (yyvsp[0].symbol)->update(new SymbolType(currentType)); // update type to the last type seen
                            currentSymbol = (yyval.symbol);
                        }
#line 3327 "y.tab.c"
    break;

  case 134:
#line 1256 "bison2.y"
                        { 
                            yyinfo("direct_declarator => ( declarator )"); 
                            (yyval.symbol) = (yyvsp[-1].symbol);
                        }
#line 3336 "y.tab.c"
    break;

  case 135:
#line 1261 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator [ type_qualifier_list assignment_expression ]"); 
                        }
#line 3344 "y.tab.c"
    break;

  case 136:
#line 1265 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator [ type_qualifier_list ]"); 
                        }
#line 3352 "y.tab.c"
    break;

  case 137:
#line 1269 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator [ assignment_expression ]"); 
                            SymbolType *it1 = (yyvsp[-3].symbol)->type, *it2 = NULL;
                            while(it1->type == SymbolType::ARRAY) { // go to the base level of a nested type
                                it2 = it1;
                                it1 = it1->arrayType;
                            }
                            if(it2 != NULL) { // nested array case
                                // another level of nesting with base as it1 and width the value of assignment_expression
                                it2->arrayType =  new SymbolType(SymbolType::ARRAY, it1, atoi((yyvsp[-1].expression)->symbol->initialValue.c_str()));	
                                (yyval.symbol) = (yyvsp[-3].symbol)->update((yyvsp[-3].symbol)->type);
                            }
                            else { // fresh array
                                // create a new array with base as type of direct_declarator and width the value of assignment_expression
                                (yyval.symbol) = (yyvsp[-3].symbol)->update(new SymbolType(SymbolType::ARRAY, (yyvsp[-3].symbol)->type, atoi((yyvsp[-1].expression)->symbol->initialValue.c_str())));
                            }
                        }
#line 3374 "y.tab.c"
    break;

  case 138:
#line 1287 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator [ ]"); 
                            // same as the previous rule, just we dont know the size so put it as 0
                            SymbolType *it1 = (yyvsp[-2].symbol)->type, *it2 = NULL;
                            while(it1->type == SymbolType::ARRAY) { // go to the base level of a nested type
                                it2 = it1;
                                it1 = it1->arrayType;
                            }
                            if(it2 != NULL) { // nested array case
                                // another level of nesting with base as it1 and width the value of assignment_expression
                                it2->arrayType =  new SymbolType(SymbolType::ARRAY, it1, 0);	
                                (yyval.symbol) = (yyvsp[-2].symbol)->update((yyvsp[-2].symbol)->type);
                            }
                            else { // fresh array
                                // create a new array with base as type of direct_declarator and width the value of assignment_expression
                                (yyval.symbol) = (yyvsp[-2].symbol)->update(new SymbolType(SymbolType::ARRAY, (yyvsp[-2].symbol)->type, 0));
                            }
                        }
#line 3397 "y.tab.c"
    break;

  case 139:
#line 1306 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator [ static type_qualifier_list assignment_expression ]"); 
                        }
#line 3405 "y.tab.c"
    break;

  case 140:
#line 1310 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator [ assignment_expression ]"); 
                        }
#line 3413 "y.tab.c"
    break;

  case 141:
#line 1314 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator [ type_qualifier_list static assignment_expression ]"); 
                        }
#line 3421 "y.tab.c"
    break;

  case 142:
#line 1318 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator [ type_qualifier_list * ]"); 
                        }
#line 3429 "y.tab.c"
    break;

  case 143:
#line 1322 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator [ * ]"); 
                        }
#line 3437 "y.tab.c"
    break;

  case 144:
#line 1326 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator ( parameter_type_list )"); 
                            // function declaration
                            currentTable->name = (yyvsp[-4].symbol)->name;
                            if((yyvsp[-4].symbol)->type->type != SymbolType::VOID) {
                                // set type of return value
                                currentTable->lookup("return")->update((yyvsp[-4].symbol)->type);
                            }
                            // move back to the global table and set the nested table for the function
                            (yyvsp[-4].symbol)->nestedTable = currentTable;
                            currentTable->parent = globalTable;
                            changeTable(globalTable);
                            currentSymbol = (yyval.symbol);
                        }
#line 3456 "y.tab.c"
    break;

  case 145:
#line 1341 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator ( identifier_list )"); 
                        }
#line 3464 "y.tab.c"
    break;

  case 146:
#line 1345 "bison2.y"
                        { 
                            yyinfo("direct_declarator => direct_declarator ( )"); 
                            // same as the previous rule
                            currentTable->name = (yyvsp[-3].symbol)->name;
                            if((yyvsp[-3].symbol)->type->type != SymbolType::VOID) {
                                // set type of return value
                                currentTable->lookup("return")->update((yyvsp[-3].symbol)->type);
                            }
                            // move back to the global table and set the nested table for the function
                            (yyvsp[-3].symbol)->nestedTable = currentTable;
                            currentTable->parent = globalTable;
                            changeTable(globalTable);
                            currentSymbol = (yyval.symbol);
                        }
#line 3483 "y.tab.c"
    break;

  case 147:
#line 1363 "bison2.y"
                            { 
                                yyinfo("type_qualifier_list_opt => type_qualifier_list"); 
                            }
#line 3491 "y.tab.c"
    break;

  case 148:
#line 1367 "bison2.y"
                            { 
                                yyinfo("type_qualifier_list_opt => e"); 
                            }
#line 3499 "y.tab.c"
    break;

  case 149:
#line 1401 "bison2.y"
            { 
                yyinfo("pointer => * type_qualifier_list_opt"); 
                // fresh pointer
                (yyval.symbolType) = new SymbolType(SymbolType::POINTER);
            }
#line 3509 "y.tab.c"
    break;

  case 150:
#line 1407 "bison2.y"
            { 
                yyinfo("pointer => * type_qualifier_list_opt pointer"); 
                // nested pointer
                (yyval.symbolType) = new SymbolType(SymbolType::POINTER, (yyvsp[0].symbolType));
            }
#line 3519 "y.tab.c"
    break;

  case 151:
#line 1416 "bison2.y"
                        { 
                            yyinfo("type_qualifier_list => type_qualifier"); 
                        }
#line 3527 "y.tab.c"
    break;

  case 152:
#line 1420 "bison2.y"
                        { 
                            yyinfo("type_qualifier_list => type_qualifier_list type_qualifier"); 
                        }
#line 3535 "y.tab.c"
    break;

  case 153:
#line 1427 "bison2.y"
                        { 
                            yyinfo("parameter_type_list => parameter_list"); 
                        }
#line 3543 "y.tab.c"
    break;

  case 154:
#line 1431 "bison2.y"
                        { 
                            yyinfo("parameter_type_list => parameter_list , ..."); 
                        }
#line 3551 "y.tab.c"
    break;

  case 155:
#line 1438 "bison2.y"
                    { 
                        yyinfo("parameter_list => parameter_declaration"); 
                    }
#line 3559 "y.tab.c"
    break;

  case 156:
#line 1442 "bison2.y"
                    { 
                        yyinfo("parameter_list => parameter_list , parameter_declaration"); 
                    }
#line 3567 "y.tab.c"
    break;

  case 157:
#line 1449 "bison2.y"
                            { 
                                yyinfo("parameter_declaration => declaration_specifiers declarator"); 
                            }
#line 3575 "y.tab.c"
    break;

  case 158:
#line 1453 "bison2.y"
                            { 
                                yyinfo("parameter_declaration => declaration_specifiers"); 
                            }
#line 3583 "y.tab.c"
    break;

  case 159:
#line 1460 "bison2.y"
                    { 
                        yyinfo("identifier_list => IDENTIFIER"); 
                    }
#line 3591 "y.tab.c"
    break;

  case 160:
#line 1464 "bison2.y"
                    { 
                        yyinfo("identifier_list => identifier_list , IDENTIFIER"); 
                    }
#line 3599 "y.tab.c"
    break;

  case 161:
#line 1471 "bison2.y"
                { 
                    yyinfo("type_name => specifier_qualifier_list"); 
                }
#line 3607 "y.tab.c"
    break;

  case 162:
#line 1478 "bison2.y"
                { 
                    yyinfo("initialiser => assignment_expression"); 
                    (yyval.symbol) = (yyvsp[0].expression)->symbol;
                }
#line 3616 "y.tab.c"
    break;

  case 163:
#line 1483 "bison2.y"
                { 
                    yyinfo("initialiser => { initialiser_list }"); 
                }
#line 3624 "y.tab.c"
    break;

  case 164:
#line 1487 "bison2.y"
                { 
                    yyinfo("initialiser => { initialiser_list , }"); 
                }
#line 3632 "y.tab.c"
    break;

  case 165:
#line 1494 "bison2.y"
                        { 
                            yyinfo("initialiser_list => designation_opt initialiser"); 
                        }
#line 3640 "y.tab.c"
    break;

  case 166:
#line 1498 "bison2.y"
                        { 
                            yyinfo("initialiser_list => initialiser_list , designation_opt initialiser"); 
                        }
#line 3648 "y.tab.c"
    break;

  case 167:
#line 1505 "bison2.y"
                    { 
                        yyinfo("designation_opt => designation"); 
                    }
#line 3656 "y.tab.c"
    break;

  case 168:
#line 1509 "bison2.y"
                    { 
                        yyinfo("designation_opt => e"); 
                    }
#line 3664 "y.tab.c"
    break;

  case 169:
#line 1516 "bison2.y"
                { 
                    yyinfo("designation => designator_list ="); 
                }
#line 3672 "y.tab.c"
    break;

  case 170:
#line 1523 "bison2.y"
                    { 
                        yyinfo("designator_list => designator"); 
                    }
#line 3680 "y.tab.c"
    break;

  case 171:
#line 1527 "bison2.y"
                    { 
                        yyinfo("designator_list => designator_list designator"); 
                    }
#line 3688 "y.tab.c"
    break;

  case 172:
#line 1534 "bison2.y"
                { 
                    yyinfo("designator => [ constant_expression ]"); 
                }
#line 3696 "y.tab.c"
    break;

  case 173:
#line 1538 "bison2.y"
                { 
                    yyinfo("designator => . IDENTIFIER"); 
                }
#line 3704 "y.tab.c"
    break;

  case 174:
#line 1547 "bison2.y"
                { 
                    yyinfo("statement => labeled_statement"); 
                }
#line 3712 "y.tab.c"
    break;

  case 175:
#line 1551 "bison2.y"
                { 
                    yyinfo("statement => compound_statement");
                    (yyval.statement) = (yyvsp[0].statement); 
                }
#line 3721 "y.tab.c"
    break;

  case 176:
#line 1556 "bison2.y"
                { 
                    yyinfo("statement => expression_statement"); 
                    (yyval.statement) = new Statement();
                    (yyval.statement)->nextList = (yyvsp[0].expression)->nextList;
                }
#line 3731 "y.tab.c"
    break;

  case 177:
#line 1562 "bison2.y"
                { 
                    yyinfo("statement => selection_statement"); 
                    (yyval.statement) = (yyvsp[0].statement);
                }
#line 3740 "y.tab.c"
    break;

  case 178:
#line 1567 "bison2.y"
                { 
                    yyinfo("statement => iteration_statement"); 
                    (yyval.statement) = (yyvsp[0].statement);
                }
#line 3749 "y.tab.c"
    break;

  case 179:
#line 1572 "bison2.y"
                { 
                    yyinfo("statement => jump_statement"); 
                    (yyval.statement) = (yyvsp[0].statement);
                }
#line 3758 "y.tab.c"
    break;

  case 180:
#line 1580 "bison2.y"
                        { 
                            yyinfo("labeled_statement => IDENTIFIER : statement"); 
                        }
#line 3766 "y.tab.c"
    break;

  case 181:
#line 1584 "bison2.y"
                        { 
                            yyinfo("labeled_statement => case constant_expression : statement"); 
                        }
#line 3774 "y.tab.c"
    break;

  case 182:
#line 1588 "bison2.y"
                        { 
                            yyinfo("labeled_statement => default : statement"); 
                        }
#line 3782 "y.tab.c"
    break;

  case 183:
#line 1599 "bison2.y"
                    {
                        string name = currentTable->name + "_" + toString(tableCount);
                        tableCount++;
                        Symbol *s = currentTable->lookup(name); // create new entry in symbol table
                        s->nestedTable = new SymbolTable(name, currentTable);
                        s->type = new SymbolType(SymbolType::BLOCK);
                        currentSymbol = s;
                    }
#line 3795 "y.tab.c"
    break;

  case 184:
#line 1611 "bison2.y"
                        { 
                            yyinfo("compound_statement => { block_item_list_opt }"); 
                            (yyval.statement) = (yyvsp[-1].statement);
                            changeTable(currentTable->parent); // block over, move back to the parent table
                        }
#line 3805 "y.tab.c"
    break;

  case 185:
#line 1620 "bison2.y"
                        { 
                            yyinfo("block_item_list_opt => block_item_list"); 
                            (yyval.statement) = (yyvsp[0].statement);
                        }
#line 3814 "y.tab.c"
    break;

  case 186:
#line 1625 "bison2.y"
                        { 
                            yyinfo("block_item_list_opt => e"); 
                            (yyval.statement) = new Statement();
                        }
#line 3823 "y.tab.c"
    break;

  case 187:
#line 1633 "bison2.y"
                    {
                        yyinfo("block_item_list => block_item"); 
                        (yyval.statement) = (yyvsp[0].statement);
                    }
#line 3832 "y.tab.c"
    break;

  case 188:
#line 1638 "bison2.y"
                    { 
                        yyinfo("block_item_list => block_item_list block_item"); 
                        (yyval.statement) = (yyvsp[0].statement);
                        // after completion of block_item_list(1) we move to block_item(3)
                        backpatch((yyvsp[-2].statement)->nextList,(yyvsp[-1].instructionNumber));
                    }
#line 3843 "y.tab.c"
    break;

  case 189:
#line 1648 "bison2.y"
                { 
                    yyinfo("block_item => declaration"); 
                    (yyval.statement) = new Statement();
                }
#line 3852 "y.tab.c"
    break;

  case 190:
#line 1653 "bison2.y"
                { 
                    yyinfo("block_item => statement"); 
                    (yyval.statement) = (yyvsp[0].statement);
                }
#line 3861 "y.tab.c"
    break;

  case 191:
#line 1661 "bison2.y"
                            { 
                                yyinfo("expression_statement => expression_opt ;"); 
                                (yyval.expression) = (yyvsp[-1].expression);
                            }
#line 3870 "y.tab.c"
    break;

  case 192:
#line 1669 "bison2.y"
                    { 
                        yyinfo("expression_opt => expression"); 
                        (yyval.expression) = (yyvsp[0].expression);
                    }
#line 3879 "y.tab.c"
    break;

  case 193:
#line 1674 "bison2.y"
                    { 
                        yyinfo("expression_opt => e"); 
                        (yyval.expression) = new Expression();
                    }
#line 3888 "y.tab.c"
    break;

  case 194:
#line 1695 "bison2.y"
                        { 
                            yyinfo("selection_statement => if ( expression ) statement"); 
                            (yyval.statement) = new Statement();
                            (yyvsp[-4].expression)->toBool();
                            backpatch((yyvsp[-4].expression)->trueList, (yyvsp[-2].instructionNumber)); // if true go to M
                            (yyval.statement)->nextList = merge((yyvsp[-4].expression)->falseList, merge((yyvsp[-1].statement)->nextList, (yyvsp[0].statement)->nextList)); // exits
                        }
#line 3900 "y.tab.c"
    break;

  case 195:
#line 1703 "bison2.y"
                        { 
                            yyinfo("selection_statement => if ( expression ) statement else statement"); 
                            (yyval.statement) = new Statement();
                            (yyvsp[-7].expression)->toBool();
                            backpatch((yyvsp[-7].expression)->trueList, (yyvsp[-5].instructionNumber)); // if true go to M
                            backpatch((yyvsp[-7].expression)->falseList, (yyvsp[-1].instructionNumber)); // if false go to else
                            (yyval.statement)->nextList = merge((yyvsp[0].statement)->nextList, merge((yyvsp[-4].statement)->nextList, (yyvsp[-3].statement)->nextList)); // exits
                        }
#line 3913 "y.tab.c"
    break;

  case 196:
#line 1712 "bison2.y"
                        { 
                            yyinfo("selection_statement => switch ( expression ) statement"); 
                        }
#line 3921 "y.tab.c"
    break;

  case 197:
#line 1738 "bison2.y"
                        { 
                            yyinfo("iteration_statement => while ( expression ) statement"); 
                            (yyval.statement) = new Statement();
                            (yyvsp[-3].expression)->toBool();
                            backpatch((yyvsp[0].statement)->nextList, (yyvsp[-5].instructionNumber)); // after statement go back to M1
                            backpatch((yyvsp[-3].expression)->trueList, (yyvsp[-1].instructionNumber)); // if true go to M2
                            (yyval.statement)->nextList = (yyvsp[-3].expression)->falseList; // exit if false
                            emit("goto", toString((yyvsp[-5].instructionNumber)));
                        }
#line 3935 "y.tab.c"
    break;

  case 198:
#line 1748 "bison2.y"
                        { 
                            yyinfo("iteration_statement => do statement while ( expression ) ;"); 
                            (yyval.statement) = new Statement();
                            (yyvsp[-2].expression)->toBool();
                            backpatch((yyvsp[-2].expression)->trueList, (yyvsp[-7].instructionNumber)); // if true go back to M1
                            backpatch((yyvsp[-6].statement)->nextList, (yyvsp[-5].instructionNumber)); // after statement is executed go to M2
                            (yyval.statement)->nextList = (yyvsp[-2].expression)->falseList; // exit if false
                        }
#line 3948 "y.tab.c"
    break;

  case 199:
#line 1757 "bison2.y"
                        { 
                            yyinfo("iteration_statement => for ( expression_opt ; expression_opt ; expression_opt ) statement"); 
                            (yyval.statement) = new Statement();
                            (yyvsp[-7].expression)->toBool();
                            backpatch((yyvsp[-7].expression)->trueList, (yyvsp[-1].instructionNumber)); // if true go to M3 (loop body)
                            backpatch((yyvsp[-3].statement)->nextList, (yyvsp[-8].instructionNumber)); // after N go to M1 (condition check)
                            backpatch((yyvsp[0].statement)->nextList, (yyvsp[-5].instructionNumber)); // after S1 (loop body) go to M2 (increment/decrement/any other operation)
                            emit("goto", toString((yyvsp[-5].instructionNumber)));
                            (yyval.statement)->nextList = (yyvsp[-7].expression)->falseList; // exit if false
                        }
#line 3963 "y.tab.c"
    break;

  case 200:
#line 1768 "bison2.y"
                        { 
                            yyinfo("iteration_statement => for ( declaration expression_opt ; expression_opt ) statement"); 
                        }
#line 3971 "y.tab.c"
    break;

  case 201:
#line 1775 "bison2.y"
                    { 
                        yyinfo("jump_statement => goto IDENTIFIER ;"); 
                    }
#line 3979 "y.tab.c"
    break;

  case 202:
#line 1779 "bison2.y"
                    { 
                        yyinfo("jump_statement => continue ;"); 
                    }
#line 3987 "y.tab.c"
    break;

  case 203:
#line 1783 "bison2.y"
                    { 
                        yyinfo("jump_statement => break ;"); 
                    }
#line 3995 "y.tab.c"
    break;

  case 204:
#line 1787 "bison2.y"
                    { 
                        yyinfo("jump_statement => return expression_opt ;"); 
                        (yyval.statement) = new Statement();
                        if((yyvsp[-1].expression)->symbol != NULL) {
                            emit("return", (yyvsp[-1].expression)->symbol->name); // emit the current symbol name at return if it exists otherwise empty
                        } else {
                            emit("return", "");
                        }
                    }
#line 4009 "y.tab.c"
    break;

  case 205:
#line 1802 "bison2.y"
                        { 
                            yyinfo("translation_unit => external_declaration"); 
                        }
#line 4017 "y.tab.c"
    break;

  case 206:
#line 1806 "bison2.y"
                        { 
                            yyinfo("translation_unit => translation_unit external_declaration"); 
                        }
#line 4025 "y.tab.c"
    break;

  case 207:
#line 1813 "bison2.y"
                            { 
                                yyinfo("external_declaration => function_definition"); 
                            }
#line 4033 "y.tab.c"
    break;

  case 208:
#line 1817 "bison2.y"
                            { 
                                yyinfo("external_declaration => declaration"); 
                            }
#line 4041 "y.tab.c"
    break;

  case 209:
#line 1825 "bison2.y"
                        { 
                            yyinfo("function_definition => declaration_specifiers declarator declaration_list_opt compound_statement"); 
                            tableCount = 0;
                            (yyvsp[-5].symbol)->isFunction = true;
                            changeTable(globalTable);
                        }
#line 4052 "y.tab.c"
    break;

  case 210:
#line 1835 "bison2.y"
                            { 
                                yyinfo("declaration_list_opt => declaration_list"); 
                            }
#line 4060 "y.tab.c"
    break;

  case 211:
#line 1839 "bison2.y"
                            { 
                                yyinfo("declaration_list_opt => e"); 
                            }
#line 4068 "y.tab.c"
    break;

  case 212:
#line 1846 "bison2.y"
                        { 
                            yyinfo("declaration_list => declaration"); 
                        }
#line 4076 "y.tab.c"
    break;

  case 213:
#line 1850 "bison2.y"
                        { 
                            yyinfo("declaration_list => declaration_list declaration"); 
                        }
#line 4084 "y.tab.c"
    break;


#line 4088 "y.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *, YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;


#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif


/*-----------------------------------------------------.
| yyreturn -- parsing is finished, return the result.  |
`-----------------------------------------------------*/
yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[+*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 1855 "bison2.y"


void yyerror(string s) {
    printf("ERROR [Line %d] : %s\n", yylineno, s.c_str());
}

void yyinfo(string s) {
    #ifdef _DEBUG
        printf("INFO [Line %d] : %s\n", yylineno, s.c_str());
    #endif
}

void yyreduce(string s) {
    #ifdef _DEBUG
        printf("INFO [Line %d] : %s\n", yylineno, s.c_str());
    #endif
}
